#ifndef UMFPACK_WRAPER_H
#define UMFPACK_WRAPER_H



#include <stdio.h>
#include "umfpack.h"

/* #include <cstdio>
using namespace std;
*/

//extern "C" 
void UMFPACKSolveLinearEquations( int n, int *Ap, int *Ai, double *Ax, double *b,  double *sol );


#if 0

// fix some issues
void *(*amd_malloc) (size_t) = malloc ;
void (*amd_free) (void *) = free ;
void *(*amd_realloc) (void *, size_t) = realloc ;
void *(*amd_calloc) (size_t, size_t) = calloc ;


extern "C" void amd_defaults
(
    double Control [ ]
);


// this file is a wraper for GLPK solver

extern "C" int umfpack_di_symbolic
(
int n_row,
int n_col,
const int Ap [ ],
const int Ai [ ],
const double Ax [ ],
void **Symbolic,
const double Control [UMFPACK_CONTROL],
double Info [UMFPACK_INFO]
);


extern "C" int umfpack_di_numeric
(
const int Ap [ ],
const int Ai [ ],
const double Ax [ ],
void *Symbolic,
void **Numeric,
const double Control [UMFPACK_CONTROL],
double Info [UMFPACK_INFO]
) ;

extern "C" int umfpack_di_solve
(
int sys,
const int Ap [ ],
const int Ai [ ],
const double Ax [ ],
double X [ ],
const double B [ ],
void *Numeric,
const double Control [UMFPACK_CONTROL],
double Info [UMFPACK_INFO]
) ;


extern "C" void umfpack_di_free_symbolic
(
void **Symbolic
) ;

extern "C" void umfpack_di_free_numeric
(
void **Numeric
) ;

extern "C" void umfpack_di_defaults
(
double Control [UMFPACK_CONTROL]
) ;


#endif


#endif	// UMFPACK_WRAPER_H

