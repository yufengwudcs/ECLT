#ifndef MATRIX_UTILS_H
#define MATRIX_UTILS_H

#include "Utils3.h"
#include "BinaryMatrix.h"
#include <vector>
#include <set>
#include <map>
using namespace std;


// Simple utils here
#include "matrix_h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// Interface for matrix utilites such as matrix inversion
// here we assume it is double matrix (should be a template)

class AbstractMatrixUtils
{
public:
	AbstractMatrixUtils(const vector<vector< double > > &rows) : listMatRows(rows)  {}
	virtual ~AbstractMatrixUtils() {}
	virtual void Invert() = 0;
	double GetMatCell(int i, int j) { return listMatRows[i][j]; }
	void Dump()
	{
		for(int i=0; i<(int)listMatRows.size(); ++i)
		{
			for(int j=0; j<(int)listMatRows.size(); ++j)
			{
				cout << listMatRows[i][j] << "   ";
			}
			cout << endl;
		}
	}

protected:
	vector<vector< double > > listMatRows;
};



//////////////////////////////////////////////////////////////////////////////////////////////////
// based on a simple inversion code

class SimpleSquareMatrixUtils : public AbstractMatrixUtils
{
public:
	SimpleSquareMatrixUtils(const vector<vector< double > > &rows) : AbstractMatrixUtils(rows), matSimple(rows.size(), rows.size() )  
	{
		// force to be square
		YW_ASSERT_INFO( rows.size() > 0 && rows.size() == rows[0].size(), "Input is wrong" );

		// setup values
		for(int i=0; i<(int)rows.size(); ++i)
		{
			for(int j=0; j<(int)rows[i].size(); ++j)
			{
				matSimple.setvalue(i, j, rows[i][j] );
			}
		}
	}

	virtual void Invert()
	{
		matSimple.invert();
		// get the new values
		for(int i=0; i<(int)listMatRows.size(); ++i)
		{
			for(int j=0; j<(int)listMatRows[i].size(); ++j)
			{
				double val;
				bool flag;
				matSimple.getvalue(i, j, val, flag );
				listMatRows[i][j]  = val;
			}
		}	
	}

private:
	matrix <double> matSimple;
};




#endif //MATRIX_UTILS_H
