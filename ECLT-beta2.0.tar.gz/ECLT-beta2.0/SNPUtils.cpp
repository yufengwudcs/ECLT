#include <sstream>
#include "SNPUtils.h"
#include <cmath>

#include <iostream>
#include <fstream>

using namespace std;


//*****************************************************************************************************

SNPDistInfo SNPDefaultDistInfo;


//*****************************************************************************************************

bool ReadSNPNameFile(  const string &filename, vector<string> &nameSNPs, vector<double> &snpPos )
{
	ifstream inFile( filename.c_str()  );
	if(!inFile)
	{
		cout << "Can not open "<< filename <<endl;
		return false;;
	}

	// Now, we first check one row to find out how many sites
//	const int MAX_BUF_SZ = 4096;
//	char buf[MAX_BUF_SZ];		// assume maximum sites allowed are 4096

	// read in SNP names (for now, only SNP name appears in the single line of text
	while( !inFile.eof()  )
	{
		string strName;
		double pos;
		inFile >> strName >> pos;
//cout << "Found one SNP " << strName << ", pos = " << pos << endl;
//		inFile.getline(buf, MAX_BUF_SZ);
		string sname = strName;
		nameSNPs.push_back( sname );
		snpPos.push_back( pos );
	}

    inFile.close();
	return true;
}

//*****************************************************************************************************
// THis is the class that mainly control how we can solve the problem

SNPDistInfo :: SNPDistInfo( )
{
}

SNPDistInfo :: ~SNPDistInfo()
{
}


// Now read in from a file
bool SNPDistInfo :: ReadFromFile( const char* fileName )
{
//cout << "File name in ReadFromFile = " << fileName << endl;
	// Now read in configuration file 
	ifstream distFile( fileName  );
	if(distFile.is_open()  == false)
	{
		// alert
        return false;
	}    

    // Now start to read in the distance
    phyLocSNPs.clear();

    // Read in a single line from it
    char buf[10240];
    distFile.getline(buf, 10240);
	distFile.close();

    // Check to see if the line contains all numbers
    for(unsigned int i=0; i<strlen(buf); ++i)
    {
//        if(buf[i] != ' ' && buf[i] != ',' && ( buf[i] < '0' || buf[i] >'9' ) )
        if( (buf[i] >= 'a' &&  buf[i] <= 'z')  ||  (buf[i] >='A' && buf[i] <= 'Z' )  )
        {
            // not a good distance
//cout << "First line does not contain all numbers.\n";
            distFile.close();
            return false;
        }
    }

    // Look like good distance here
    istringstream strStream( buf );

//    while(  strStream.eof() == false  )
//    {
    double dist;
    while( strStream >> dist)
    {
        phyLocSNPs.push_back( dist );
//cout << "Read in one distance: " << dist << endl;

    }

    // close the file
    distFile.close();
//cout <<"Before quitting...\n";
    // Finish 
    return true;
}

int SNPDistInfo :: GetSNPNum()
{
    return phyLocSNPs.size();
}

int SNPDistInfo :: GetSNPLoc( int i ) 
{
    YW_ASSERT_INFO(  i < GetSNPNum(), "Range exceeded in SNP" );
    return (int)phyLocSNPs[i];
}

double SNPDistInfo :: GetLocBetweenSNPs(int i, int j)
{
    double res = (phyLocSNPs[i] + phyLocSNPs[j] )/2.0;
    return res;
}

void SNPDistInfo :: RemoveSNPs( const set<int> &rmSites )
{
//cout << "In RemoveSNPs: rmSites = ";
//DumpIntSet( rmSites );
//cout << "Beore removal: phyLocSNPs = ";
//DumpIntVec( phyLocSNPs );
    vector<double> phyLocNew;
    for( unsigned int i=0; i < phyLocSNPs.size(); ++i )
    {
        if( rmSites.find( i ) == rmSites.end()  )
        {
            phyLocNew.push_back( phyLocSNPs[i] );
        }
    }
    phyLocSNPs = phyLocNew;
//cout << "After removal, phyLocSNPs = ";
//DumpIntVec( phyLocSNPs );
}


double SNPDistInfo :: GetSNPLocDouble(int i)
{
    YW_ASSERT_INFO(  i < GetSNPNum(), "Range exceeded in SNP" );
    return phyLocSNPs[i];

}

//*****************************************************************************************************
void SNPDistInfo :: InitDefaultDistance(int numSNPs)
{
    phyLocSNPs.clear();
    // We create a default distance of very large size, say 10000 sites
    for(int i=0; i<numSNPs; ++i)
    {
        phyLocSNPs.push_back ( i );
    }
}


