#include "TreeCfgExpSubdivided.h"
#include <cmath>
using namespace std;

// Sparse matrix xolver
//#include "umfpack.h"
//#include "UMFPACKWraper.h"

// for convenience
extern "C" void UMFPACKSolveLinearEquations( int n, int *Ap, int *Ai, double *Ax, double *b,  double *sol );



extern unsigned long hashDJB2(const vector<int> &buf);



TreeACSubdivided :: TreeACSubdivided(const vector<int> &initEvts) : setACActiveEventIds(initEvts)
{
	int numSACs = GetNumSACs() ;
	//
	// create a temp set
//	pSetTempIds = new set<int>;
	pProbValue = new double*[RootedTreeACHelper::Instance().GetThetaNum() ];
	int numSubPop = RootedTreeACHelper::Instance().GetSubPopulationNum();
	YW_ASSERT_INFO( numSubPop >= 1, "numSubPop is zero" );
	for( int t=0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t )
	{
		pProbValue[t] = new double[ numSACs ];
		for(int i=0; i<numSACs; ++i)
		{
			pProbValue[t][i] = 1.0;
		}
	}
	ancestralACs.clear();
}

TreeACSubdivided :: TreeACSubdivided( const TreeACSubdivided &rhs) : setACActiveEventIds(rhs.setACActiveEventIds)  //, 
	//setNextEvents( rhs.setNextEvents )
	//probValue(rhs.probValue)
	//, hashVal(rhs.hashVal)
{
	// problem: we need to allocate memory for probablity, whose size is determined
	// by the number of events.
	// however, if later we add new events, we got problem: we need to allocate new buffer
	// but this involves more operations. So for now, let us ignore this possibility
	YW_ASSERT_INFO(false, "Copy constructor of TreeACSubdivided: not implemented");
	// create a temp set
	int numSACs = GetNumSACs();
cout << "Copy constructor of TreeACSubdivided: numSACs = " << numSACs <<endl;

//	pSetTempIds = new set<int>(*(rhs->pSetTempIds));
	pProbValue = new double*[RootedTreeACHelper::Instance().GetThetaNum() ];
	for( int t=0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t )
	{
		pProbValue[t] = new double[ numSACs ];
		for(int i=0; i<numSACs; ++i)
		{
			pProbValue[t][i] = rhs.pProbValue[t][i];
		}
	}
	// note: do not copy ancestral list: it is rather transient
}

TreeACSubdivided :: ~TreeACSubdivided()
{
	for( int t=0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t )
	{
		delete [] pProbValue[t];
	}
	delete [] pProbValue;
}


// interfaces
int TreeACSubdivided :: GetNumSeqs()
{
	// num seq = number of coalescent event + 1
	int res = 1; 
	res += RootedTreeACHelper :: Instance().GetNumCoalsentEvents(this->setACActiveEventIds);
		
	return res;
}

bool TreeACSubdivided :: IsSame( TreeAC *pAC ) 
{
	TreeACSubdivided *pACPan = dynamic_cast<TreeACSubdivided *>(pAC);
	if( pACPan != NULL )
	{
		return IsSameSubdivid(pACPan); 
	}
	else
	{
		// not the same if of different type
		return false;
	}
}

bool TreeACSubdivided :: IsSameSubdivid( TreeACSubdivided *pAC )
{

	if( this->setACActiveEventIds.size() != pAC->setACActiveEventIds.size() )
	{
		return false;
	}

	for( int i=0; i<(int) this->setACActiveEventIds.size(); ++i )
	{
		if( this->setACActiveEventIds[i] != pAC->setACActiveEventIds[i] )
		{
			return false;
		}
	}
	return true;
}



void TreeACSubdivided :: GetNextACs( vector<TreeAC *> &listNewACs ) 
{
	// crucial here
	listNewACs.clear();

	// find out what next events to explore from the current active ones
	//set<int> setCurEvts;
	//PopulateSetByVec( setCurEvts, this->setACActiveEventIds );
	set<int> setNextEvents;
	for( vector<int> :: iterator it = this->setACActiveEventIds.begin(); it != this->setACActiveEventIds.end(); ++it )
	{
		int evtCur = *it;
		UpdateNextEvents(evtCur, setNextEvents);
	}

//	int numSeqs = this->GetNumSeqs();
//cout << "GetNextACs: numSeqs = "<< numSeqs << endl;
//this->Dump();

	// for now, every event is placed to active
	for( set<int> :: iterator it = setNextEvents.begin(); it != setNextEvents.end(); ++it )
	{
		//set<int> evtIdActive = this->setACActiveEventIds;
//		set<int> evtIdDead = this->setACDeadEventIds;
		// add to active ids. TBD!
		//evtIdActive.insert( *it );

		vector<int> listEvtsNew = this->setACActiveEventIds;
		InsertOrderedVec(listEvtsNew, *it);

		TreeACSubdivided *pAC = new TreeACSubdivided( listEvtsNew );
//cout << "Create AC address: " << (int) pAC << endl;

		// add one more event
		//pAC->AddActiveEvent( *it );
//cout << "Evets list pf pAC: ";
//DumpIntVec(pAC->setACActiveEventIds);
		// YW: 061209, need to register the first it is created. CHECK it
		// add this new one
		pAC->AddAncestralAC( this );
//cout << "Aggragate\n";
		// update its prob here
		//if( RootedTreeACHelper::Instance().IsEventCoalescent(*it) == true )
		//{
		//	// this is a coalescent event
		//	int numCoalSeq = RootedTreeACHelper::Instance().GetLocalCoalNum(*it) + 1;
		//	// mutation event
		//	set<int> setEvtsInt;
		//	//ConvCharSetToIntSet( pAC->setACActiveEventIds, setEvtsInt );
		//	PopulateSetByVec( setEvtsInt, pAC->setACActiveEventIds );
		//	int numMutedBranches = RootedTreeACHelper::Instance().GetNumLocalMutEvtBranches(*it, setEvtsInt);
		//	pAC->UpdateByCoalescent( numSeqs+1, numCoalSeq - numMutedBranches);
		//}
		//else
		//{
		//	// mutation event
		//	set<int> setEvtsInt;
//		//	ConvCharSetToIntSet( pAC->setACActiveEventIds, setEvtsInt );
		//	PopulateSetByVec( setEvtsInt, pAC->setACActiveEventIds );
		//	int numMutChoices = RootedTreeACHelper::Instance().GetNumLocalMutEvtChoices(*it, setEvtsInt);
//		//	int numMutChoices = 1;
		//	pAC->UpdateByMutation( numSeqs, numMutChoices  );
		//}
		listNewACs.push_back( pAC );
	}
//cout << "TreeACSubdivided: found list of new AC = " << listNewACs.size() << endl;
}

void TreeACSubdivided :: Dump() 
{
	// 
	cout << "AC contains: active events = ";
	DumpIntVec( this->setACActiveEventIds );
//	DumpIntSet( this->setACDeadEventIds);
//	cout<< "Next events = ";
//	DumpSet( this->setNextEvents );
	int numSACs = GetNumSACs();
	cout << "--- num SACs = " << numSACs << endl; 
	for(int t =0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t )
	{
		for(int i=0; i<numSACs; ++i)
		{
			cout << "Prob = " << pProbValue[t][i]  << endl;
		}
	}
}

void TreeACSubdivided :: AddActiveEvent(int evid ) 
{
YW_ASSERT_INFO(false, "For now, do not support adding new events to TreeACSubdivided");
	// same as the copy constructor, do not support it for now
	YW_ASSERT_INFO(false, "Add Active event of TreeACSubdivided: not implemented");
	InsertOrderedVec(this->setACActiveEventIds, evid);
cout <<  "AddActiveEvent: evets = ";
DumpIntVec(this->setACActiveEventIds);
}

void TreeACSubdivided :: Consolidate() 
{
	YW_ASSERT_INFO(false, "not supported");
}

int TreeACSubdivided :: GetSignature( )
{
	return hashDJB2( this->setACActiveEventIds );
}

double TreeACSubdivided :: GetProb(int index) 
{
	// sum of all probability of all sub-ACs?
	// no, non-informative
	return 1.0;
}

void TreeACSubdivided :: UpdateByCoalescent( int numSeq, int numCoalSeq ) 
{
	// do nothing
}

void TreeACSubdivided :: UpdateByMutation( int numSeq, int numMutSeq  ) 
{
	// do nothing
}

void TreeACSubdivided :: Aggregate( TreeAC *pAC ) 
{
//cout << "In Aggregate: ";
//this->Dump();
//return;
	// keep track what ancestral AC this has
	TreeACSubdivided *pACSub = dynamic_cast<TreeACSubdivided *>(pAC);
	YW_ASSERT_INFO( pACSub != NULL, "Wrong type of ACs" );
	// need to aggragate whatever in their list of ancestral ACs
	for(int j=0; j<(int)pACSub->ancestralACs.size(); ++j)
	{
		YW_ASSERT_INFO( pACSub->ancestralACs[j] != NULL, "Can not be NULL" );
//cout << "ancestral AC address: " << (int) pAC << endl;
//cout << "Aggragate one ancestral AC: ";
//pACSub->ancestralACs[j]->Dump();
		ancestralACs.push_back( pACSub->ancestralACs[j] );
	}
}

double TreeACSubdivided :: GetEstProbRemain() 
{
	return 1.0;
}

int TreeACSubdivided :: GetNumCurEvts() 
{
	return this->setACActiveEventIds.size();
}

int TreeACSubdivided :: GetNumSACs()
{
	// idea: for do it for each lineage. If there are n copies
	// of it, the number of partitions: x1+x2+...+xk=n
	// and number of solutions = C(k-1, n+k-1)
	// then we simply multiply it
	vector<COAL_LINEAGE> lineages;
	// get the instance
	RootedTreeACHelper::Instance().GetCurrLineages(this->setACActiveEventIds, lineages);
	int numSPop = RootedTreeACHelper::Instance().GetSubPopulationNum();
	int res = 1;

	for(int i=0; i<(int)lineages.size(); ++i)
	{
		res *= GetPartitionEnumNum( lineages[i].multiplicity, numSPop );
//		int nsub = lineages[i].multiplicity;
//		for(int j=1; j<= numSPop- 1; ++j)
//		{
//			res *= (nsub+numSPop-j)/j;
//		}
	}
//if( res < 100 )
//{
//	res = 2;
//}
//else
//{
//	res = 4;
//}
//cout << "GetNumSACs: res = " << res << endl;
	return res;


//	int numSPop = RootedTreeACHelper::Instance().GetSubPopulationNum();
//	int numSeqs = GetNumSeqs();
//	if( numSPop == 2)
//	{
//		return 0x1 << numSeqs;
//	}
//	else
//	{
//		return (int)pow((double)numSPop, (double)numSeqs);
//	}
}


void TreeACSubdivided :: UpdateNextEvents( int eid, set<int> &setNextEvents )
{
//cout << "UpdateNextEvents: eid = " << eid << endl;
	// update next event candidates after adding this new eid
	// remove the current added event
	setNextEvents.erase( eid );

	// append new events
	set<int> evtCandidates, evtToRemove;	//, setActiveEventsInt;
	
//	ConvCharSetToIntSet(this->setACActiveEventIds, setActiveEventsInt);
	set<int> setActiveEvtChars;
	//FillCharSet(setActiveEvtChars, this->setACActiveEventIds);
	PopulateSetByVec(setActiveEvtChars, this->setACActiveEventIds);
	RootedTreeACHelper::Instance().GetNextEventCandidatesForEvt( eid, setActiveEvtChars, evtCandidates, evtToRemove );
//cout << "evtCandidates = ";
	// append this to new ones (but can not have the original ones)
//	set<int> setJoin;
//	JoinSets(evtCandidates, this->setACActiveEventIds, setJoin);
//YW_ASSERT_INFO( setJoin.size() == 0, "Join sets non empty: Very wrong" );
//	SubtractSets( evtCandidates, this->setACActiveEventIds );
//	set<char> evtChars1, evtChars2;
//	ConvIntSetToCharSet( evtCandidates, evtChars1);
//	ConvIntSetToCharSet( evtToRemove, evtChars2);

	for(set<int> :: iterator it = evtCandidates.begin(); it != evtCandidates.end(); ++it)
	{
		//
		setNextEvents.insert( (int)*it );
	}
	for(set<int> :: iterator it = evtToRemove.begin(); it != evtToRemove.end(); ++it)
	{
		//
		setNextEvents.erase( (int)*it );
	}


	//UnionSets( this->setNextEvents, evtChars1 );
	//SubtractSets( this->setNextEvents, evtChars2 );

}

void TreeACSubdivided :: CalcSACProbs()
{
//cout << "---------------------------------------------------------------------------\n";
//cout << "CalcSACProbs: \n";
//this->Dump();
	// this is really what it is
	// for now, dump out related ACs (number maybe)
//cout << "CalcSACProbs: Number of ancestral ACs = " << ancestralACs.size() << endl;
//for(int i=0; i<(int)ancestralACs.size(); ++i)
//{
//ancestralACs[i]->Dump();
//}
	vector<COAL_LINEAGE> lineages;
	// get the instance
	RootedTreeACHelper::Instance().GetCurrLineages(this->setACActiveEventIds, lineages);
	int numSubPops = RootedTreeACHelper::Instance().GetSubPopulationNum();
//cout << "CalcSACProbs: current lineages: \n";
//for(int i=0; i<(int)lineages.size(); ++i)
//{
//lineages[i].Dump();
//}


// add one more lineage
//COAL_LINEAGE lin;
//lin.eidEnd = 100;
//lin.multiplicity = 4;
//lineages.push_back(lin);
//lin.eidEnd = 101;
//lin.multiplicity = 3;
//lineages.push_back(lin);
//vector<int> vecSegSizes;
//for(int i=0; i<(int)lineages.size(); ++i)
//{
//vecSegSizes.push_back(lineages[i].multiplicity);
//}
//vector< vector<int> > enumPartsId;
//InitPartitionEnum( vecSegSizes, numSubPops, enumPartsId );
//int numTotEnum = 0;
//while(true)
//{
//// ensure id can convert back and force
//int idConv = GetPartEnumIndex(vecSegSizes, numSubPops, enumPartsId );
//YW_ASSERT_INFO( idConv == numTotEnum, "ERROR: fail to convert the id back to index in enum partition" );
//cout << "idConv = " << idConv << endl;
//numTotEnum++;

//if( GetNextPartitionEnum( vecSegSizes, numSubPops, enumPartsId ) == false )
//{
//	break;
//}
//}
//cout << "numTotEnum: " << numTotEnum << endl;
//YW_ASSERT_INFO( numTotEnum == GetNumSACs(), "ERROR: SAC Id enumeration wrong" );

//YW_ASSERT_INFO(false, "Early abort");	// do nothing

//	int numTotCalc = 0;
	vector<double> rateMigCombo;
	for(int p=0; p<RootedTreeACHelper::Instance().GetSubPopulationNum(); ++p)
	{
		rateMigCombo.push_back(  RootedTreeACHelper::Instance().GetComboMigrationRate(p) );
	}

	// collect all the relevant parts for each sub-AC: enum all partition id
	vector<int> vecSegSizes;
	for(int i=0; i<(int)lineages.size(); ++i)
	{
		vecSegSizes.push_back(lineages[i].multiplicity);
	}

	// do it for each theta: the first dimension is for theta
	vector< vector< int> > vecFirstSACIndex(RootedTreeACHelper::Instance().GetThetaNum() );
	vector<  vector<double> > vecFirstSACCoeff(RootedTreeACHelper::Instance().GetThetaNum());
	vector< vector<int> > vecRelatedSACIndex;		// for migration: DOES NOT DEPEND ON THETA!!!
	vector< vector<double> > vecRelatedSACCoeffs;
	vector< vector<double> > vecRHS(RootedTreeACHelper::Instance().GetThetaNum());


	// this is the collected equations info
	vector< vector<int> > enumPartsId;
	InitPartitionEnum( vecSegSizes, numSubPops, enumPartsId );
	int numTotEnum = 0;
	while(true)
	{
//cout <<"----enumPartsId: \n";
//DumpVecSequences( enumPartsId );
		// ensure id can convert back and force
		//int idConv = GetPartEnumIndex(vecSegSizes, numSubPops, enumPartsId );
		//YW_ASSERT_INFO( idConv == numTotEnum, "ERROR: fail to convert the id back to index in enum partition" );
//cout << "idConv = " << idConv << endl;

		vector<int> vecSumPopSizes(RootedTreeACHelper::Instance().GetSubPopulationNum() );
		int nTot = 0;
		for(int i=0; i<(int)vecSumPopSizes.size(); ++i)
		{
			vecSumPopSizes[i] = 0;
		}
		for(int i=0; i<(int) enumPartsId.size(); ++i)
		{
			for(int j=0; j<(int)enumPartsId[i].size(); ++j)
			{
				vecSumPopSizes[j] += enumPartsId[i][j];
				nTot += enumPartsId[i][j];
			}
		}

		//
		vector<double> vecMigFactors;
		vector<int> vecMigNgbrSACIds;
		FindMigNgbrs( enumPartsId, vecMigFactors, vecMigNgbrSACIds );
//cout << "++++++++vecMigNgbrSACIds = ";
//DumpIntVec( vecMigNgbrSACIds );
//cout << "vecMigFactors: ";
//DumpDoubleVec( vecMigFactors );

		// save it for equation solving
		// WARNING: need to negate the coefficents in solving
		vecRelatedSACIndex.push_back( vecMigNgbrSACIds );
		vecRelatedSACCoeffs.push_back( vecMigFactors );


		// calculate
		for( int t = 0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t)
		{

			double theta = RootedTreeACHelper::Instance().GetTheta(t);
			double probDenom = CalcProbDenom( enumPartsId, theta, rateMigCombo );
//cout << "probDenom = " << probDenom << endl;

			// record this coeff
			vecFirstSACIndex[t].push_back(numTotEnum);
			vecFirstSACCoeff[t].push_back(probDenom);


			// list of items to maintain for probability calculation
			vector<int> vecPopPartSz;
			vector<int> vecPopOrig;
			vector<double> vecPartProb;
			vector<int> vecMutSz;
			vector<double> vecMutProb;

			for(int j=0; j<(int)ancestralACs.size(); ++j)
			{
//cout << "For ancestral AC ";
//ancestralACs[j]->Dump();
				//vector< int> vecSacIDsSrc;
				AC_SRC_RESULT acRes;
				ObtainSrcSAC(ancestralACs[j], lineages, enumPartsId, acRes);
//cout << "***************For ancestral AC " << j << ", acRes.vecSrcCoalSACIds = ";
//DumpIntVec(acRes.vecSrcCoalSACIds);
//cout << "acRes.vecCoalSzs = ";
//DumpIntVec(acRes.vecCoalSzs);
//cout << "acRes.vecCoalOrig = ";
//DumpIntVec(acRes.vecCoalOrig);
//cout << "acRes.vecSrcMutSACIds = ";
//DumpIntVec(acRes.vecSrcMutSACIds);
//cout << "acRes.vecMutSzs = ";
//DumpIntVec(acRes.vecMutSzs);

				// for each theta
				for(int kkk=0; kkk<(int)acRes.vecSrcCoalSACIds.size(); ++kkk)
				{
					double probSrc = ancestralACs[j]->GetProbAt(t, acRes.vecSrcCoalSACIds[kkk]);
					vecPartProb.push_back( probSrc );
					vecPopPartSz.push_back(acRes.vecCoalSzs[kkk]  );
					vecPopOrig.push_back( acRes.vecCoalOrig[kkk] );
				}
				for(int kkk=0; kkk<(int)acRes.vecSrcMutSACIds.size(); ++kkk)
				{
					double probSrc = ancestralACs[j]->GetProbAt(t, acRes.vecSrcMutSACIds[kkk]);
					vecMutProb.push_back( probSrc );
					vecMutSz.push_back(acRes.vecMutSzs[kkk]  );
				}
			}
//cout << "***************For this AC, combined info:";
//DumpDoubleVec(vecPartProb);
//cout << "vecPopPartSz = ";
//DumpIntVec(vecPopPartSz);
//cout << "vecPopOrig = ";
//DumpIntVec(vecPopOrig);
//cout << "vecMutProb = ";
//DumpDoubleVec(vecMutProb);
//cout << "vecMutSz = ";
//DumpIntVec(vecMutSz);


			double probFixedPart = CalcCoalescentMutProbPart( theta, vecSumPopSizes, vecPopPartSz, 
				vecPopOrig, vecPartProb, vecMutSz, vecMutProb, enumPartsId );
//cout << "probFixedPart = " << probFixedPart << endl;

			// save it equation solving
			vecRHS[t].push_back(probFixedPart);

		}

		// this is the index of the enumerated partion id
		numTotEnum++;

		if( GetNextPartitionEnum( vecSegSizes, numSubPops, enumPartsId ) == false )
		{
			break;
		}
	}
//cout << "numTotEnum: " << numTotEnum << endl;
	YW_ASSERT_INFO( numTotEnum == GetNumSACs(), "ERROR: SAC Id enumeration wrong" );

//cout << "numTotCalc = " << numTotCalc << endl;


	// now update this current state
	CalcMigStatesProb( vecFirstSACIndex, vecFirstSACCoeff, vecRelatedSACIndex, vecRelatedSACCoeffs, vecRHS );


#if 0
	int numSACs = GetNumSACs();

	for(int sacId=0; sacId<numSACs; ++sacId)
	{
		vector<int> listPopSeqsNum;
		bool fres = ConvSACIdToPopNumList(  lineages, sacId, listPopSeqsNum );
cout << "sacId = " << sacId << ", pop seqs = ";
DumpIntVec(listPopSeqsNum);
		if( fres == false)
		{
			// done
			break;
		}

		// find what ancestral ACs are: mutation or coalescent?
		for(int j=0; j<(int)ancestralACs.size(); ++j)
		{
			int sacIdSrc = ObtainSrcSAC(ancestralACs[j], lineages, listPopSeqsNum );
cout << "For ancestral AC " << j << ", sacIdSrc = " << sacIdSrc << endl;
			// for each theta
			for( int t = 0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t)
			{
				double probSrc = GetProbAt(t, sacIdSrc);
cout << "Find one src prob = " << probSrc << endl;
			}
		}
	}
#endif
}


void TreeACSubdivided :: ObtainSrcSAC( TreeACSubdivided *pACSrc, const vector<COAL_LINEAGE> &lineagesDest, 
									  const vector< vector<int> > &listDestSACPops, AC_SRC_RESULT &result )
{
	result.vecSrcCoalSACIds.clear();
	result.vecCoalSzs.clear();
	result.vecCoalOrig.clear();
	result.vecSrcMutSACIds.clear();
	result.vecMutSzs.clear();
	
//cout << "ObtainSrcSAC: For pACSrc = ";
//pACSrc->Dump();
//cout << "listDestSACPops: \n";
//DumpVecSequences(listDestSACPops);
////cout << "listDestSACPops: ";
////DumpIntVec( listDestSACPops );
	// get src lineages
	vector<COAL_LINEAGE> lineagesSrc;
	RootedTreeACHelper::Instance().GetCurrLineages(pACSrc->setACActiveEventIds, lineagesSrc);
//cout << "ObtainSrcSAC: Current src lineages: \n";
//for(int i=0; i<(int)lineagesSrc.size(); ++i)
//{
//lineagesSrc[i].Dump();
//}
	//vecSrcSACIds.clear();

	set<int> setEvtsSrc;
	vector<int> vecEvtsSrc;
	vector<int> vecMultiSrc;
	for( int i=0; i<(int)lineagesSrc.size(); ++i )
	{
		setEvtsSrc.insert( lineagesSrc[i].eidEnd );
		vecEvtsSrc.push_back(lineagesSrc[i].eidEnd);
		vecMultiSrc.push_back(lineagesSrc[i].multiplicity);
	}
//cout << "ObtainSrcSAC: setEvtsSrc: ";
//DumpIntSet( setEvtsSrc );
	// ensure there is no duplicate
	YW_ASSERT_INFO( setEvtsSrc.size() == lineagesSrc.size(), "ObtainSrcSAC: there is duplicate event in Src" );
	set<int> setEvtsDest;
	vector<int> vecEvtsDest;
	map<int,int> mapEvtLineageIndex;	// map end event to lineage index in list
	for( int i=0; i<(int)lineagesDest.size(); ++i )
	{
		setEvtsDest.insert( lineagesDest[i].eidEnd );
		vecEvtsDest.push_back( lineagesDest[i].eidEnd );
//cout << "mapEvtLineageIndex: eidEnd = " << lineagesDest[i].eidEnd << ", i = " << i << endl;
		mapEvtLineageIndex.insert( map<int,int> :: value_type( lineagesDest[i].eidEnd, i )  );
	}
//cout << "ObtainSrcSAC: setEvtsDest: ";
//DumpIntSet( setEvtsDest );
	YW_ASSERT_INFO( setEvtsDest.size() == lineagesDest.size(), "ObtainSrcSAC: there is duplicate event in Dest" );
	// 
	YW_ASSERT_INFO(lineagesDest.size() == lineagesSrc.size() || lineagesDest.size() == lineagesSrc.size()+1,
		"Lineages in Dest and Src not match");

	set<int> setDiff1 = setEvtsSrc;
	SubtractSets(setDiff1, setEvtsDest);
	YW_ASSERT_INFO( setDiff1.size() <= 1, "ObtainSrcSAC: setDiff1 size wrong" );
	set<int> setDiff2 = setEvtsDest;
	SubtractSets(setDiff2, setEvtsSrc);
	YW_ASSERT_INFO( setDiff2.size() == 1, "ObtainSrcSAC: setDiff2 size wrong" );
//cout << "Diff1: " << *(setDiff1.begin() ) << ", Diff2: " << *(setDiff2.begin()) << endl;

	int numSubPops = RootedTreeACHelper::Instance().GetSubPopulationNum();

	vector< vector<int> > vecPopNumsSrc;
	if( lineagesDest.size() == lineagesSrc.size() )
	{
		YW_ASSERT_INFO( setDiff1.size()==1, "ObtainSrcSAC: setDiff1 size wrong2");
		// dest lineages are one more than src
		if( RootedTreeACHelper::Instance().IsEventCoalescent( *(setDiff2.begin() ) ) == true )
		{
//cout << "ObtainSrcSAC: coalescent type\n";
			// coalescent event: avoid the diff1 one (which is ancestral to the new event)
			// by adding one more to the existing count

			// this stores other choices: say dest (2,3) can be reached by (1,3) or (2,2) through coalescent
			int coalNumInvolved = -1;
			int coalSubPopOrig = -1;
			vector<int> listOtherCoalNumInv, listOtherSPOrig;
			vector< pair< int, vector<int> > > vecOtherChoices;	

			for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
			{
//cout << "lineagesSrc[kkk].eidEnd = " << lineagesSrc[kkk].eidEnd << endl;
				if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
				{
					// get the old id
					YW_ASSERT_INFO( mapEvtLineageIndex.find(lineagesSrc[kkk].eidEnd) != mapEvtLineageIndex.end(), 
						"ObtainSrcSAC: not in mapEvtLineageIndex" );
					YW_ASSERT_INFO( mapEvtLineageIndex.find(lineagesSrc[kkk].eidEnd) != mapEvtLineageIndex.end(), "Fail to find" );
					int indexDest = mapEvtLineageIndex[ lineagesSrc[kkk].eidEnd ];
//cout << "kkk=" << kkk <<  ", indexDest = " << indexDest << endl;
					vecPopNumsSrc.push_back( listDestSACPops[indexDest]  );
				}
				else
				{
					//YW_ASSERT_INFO(mapEvtPopNums[*(setDiff2.begin())]  >= 2, "ObtainSrcSAC: coal node in this case should have at least two");
					//vecPopNumsSrc.push_back( mapEvtPopNums[*(setDiff2.begin())] -1 );
					// search for places coalescents can occur
					YW_ASSERT_INFO( mapEvtLineageIndex.find(*(setDiff2.begin()) ) != mapEvtLineageIndex.end(), 
						"ObtainSrcSAC: not in mapEvtLineageIndex" );
					YW_ASSERT_INFO( mapEvtLineageIndex[*(setDiff2.begin())] < (int)lineagesDest.size(), 
						"ObtainSrcSAC: over lineage number" );
					YW_ASSERT_INFO( lineagesDest[mapEvtLineageIndex[*(setDiff2.begin())] ].multiplicity >=2, 
						"ObtainSrcSAC: lineage multiplicity is less than 2" );
					int indexDest = mapEvtLineageIndex[ *(setDiff2.begin()) ];
//cout << "indexDest = " << indexDest << endl;
					bool fFirstChoice = true;
					for(int ppp=0; ppp<(int)listDestSACPops[indexDest].size(); ++ppp)
					{
						// size of this part >=2
						if( listDestSACPops[indexDest][ppp] >= 2 )
						{
//cout << "ppp = " << ppp << ", destsacpops: " << listDestSACPops[indexDest][ppp] << endl;
							vector<int> vecNewAdd = listDestSACPops[indexDest];
							vecNewAdd[ppp]--;
							if( fFirstChoice == true )
							{
								// use it
								vecPopNumsSrc.push_back( vecNewAdd );
								coalNumInvolved = listDestSACPops[indexDest][ppp];
								coalSubPopOrig = ppp;
								fFirstChoice = false;
							}
							else
							{
//cout << "Adding as backup: ppp = " << ppp << ", vecNewAdd: ";
//DumpIntVec( vecNewAdd );
								// save it
								//pair<int,int> qp(kkk, ppp);
								pair<int, vector<int> > qqq(kkk, vecNewAdd);
								vecOtherChoices.push_back(qqq);
								listOtherSPOrig.push_back( ppp );
								listOtherCoalNumInv.push_back(listDestSACPops[indexDest][ppp]);
							}
						}
					}
				
				}
			}


			// if we find good vec, then check to see if there is alternative choices
			if( vecPopNumsSrc.size() == lineagesSrc.size() )
			{
				int idSrc = GetPartEnumIndex(vecMultiSrc, numSubPops, vecPopNumsSrc);
				// save the coal. event
				YW_ASSERT_INFO(coalNumInvolved > 0, "Fail: coalNumInvolved");
				result.vecSrcCoalSACIds.push_back(idSrc);
				result.vecCoalSzs.push_back(coalNumInvolved);
				result.vecCoalOrig.push_back(coalSubPopOrig);

				YW_ASSERT_INFO(vecOtherChoices.size() == listOtherSPOrig.size(), "Very wrong: size mismatch");
				for(int jj=0; jj<(int)vecOtherChoices.size(); ++jj )
				{
					vector<vector<int> > vecNewAdd = vecPopNumsSrc;
					YW_ASSERT_INFO( vecOtherChoices[jj].first <(int)vecNewAdd.size(), "Array size wrong" );
					vecNewAdd[ vecOtherChoices[jj].first ] = vecOtherChoices[jj].second;
					int idSrc1 = GetPartEnumIndex(vecMultiSrc, numSubPops, vecNewAdd) ;
					//vecSrcSACIds.push_back( idSrc1 );

					result.vecSrcCoalSACIds.push_back(idSrc1);
					result.vecCoalSzs.push_back(listOtherCoalNumInv[jj] );
					result.vecCoalOrig.push_back(listOtherSPOrig[jj] );

//cout << "Found additional coal: \n";
//DumpVecSequences(vecNewAdd);
				}
			}
		}
		else
		{
//cout << "lineagesDest.size() == lineagesSrc.size(): mutation\n";
			//vector<int> posDiffDest;
			//GetVecPosNotInSet( vecEvtsDest, setEvtsSrc, posDiffDest );
			//YW_ASSERT_INFO( posDiffDest.size() == 1, "ObtainSrcSAC: posDiffDest.size is not one:" );
			//int posDestChange = posDiffDest[0];

			//vector<int> posDiffSrc;
			//GetVecPosNotInSet( vecEvtsSrc, setEvtsDest, posDiffSrc );
			//YW_ASSERT_INFO( posDiffSrc.size() == 1, "ObtainSrcSAC: posDiffSrc.size is not one:" );
			//int posSrcChange = posDiffSrc[0];

			// 
			for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
			{
				if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
				{
					// get the old id
					YW_ASSERT_INFO( mapEvtLineageIndex.find(lineagesSrc[kkk].eidEnd) != mapEvtLineageIndex.end(), 
						"ObtainSrcSAC: not in mapEvtLineageIndex" );
					int indexDest = mapEvtLineageIndex[ lineagesSrc[kkk].eidEnd ];
					vecPopNumsSrc.push_back( listDestSACPops[indexDest]  );
				}
				else
				{
					int indexDest = mapEvtLineageIndex[ *(setDiff2.begin()) ];

					// figure out which one is 1 (the rest has to be all-zero)
					//int posOne = -1;
					//for(int ppp=0; ppp<(int)listDestSACPops[indexDest].size(); ++ppp)
					//{
					//	YW_ASSERT_INFO( listDestSACPops[indexDest][ppp] <= 1, "Wrong in dest sac pops" );
					//	if( listDestSACPops[indexDest][ppp] == 1 )
					//	{
					//	}
					//}
					vecPopNumsSrc.push_back( listDestSACPops[indexDest]    );
				}
			}
			// note this is mutation event
			if( vecPopNumsSrc.size() == lineagesSrc.size() )
			{
				int idSrc = GetPartEnumIndex(vecMultiSrc, numSubPops, vecPopNumsSrc);
				result.vecSrcMutSACIds.push_back(idSrc);
				result.vecMutSzs.push_back( 1 );	// in this case, the mutation lineage remain one
			}

		}
	}
	else
	{

//cout << "ObtainSrcSAC: mutation type\n";

		// mutation event
		// now update it by adding one more to the proper location
		int evtCoalDest = RootedTreeACHelper::Instance().GetEnclosingCoalEvt(*(setDiff2.begin()), this->setACActiveEventIds);
//cout << "evtCoalDest: " << evtCoalDest << endl;
		int numMutBranchNum = -1;
		for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
		{
			// setDiff1 is not valid here, need to know which lineage it coalesces into
			//if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
			//{
			// get the old id
			YW_ASSERT_INFO( mapEvtLineageIndex.find(lineagesSrc[kkk].eidEnd) != mapEvtLineageIndex.end(), 
				"ObtainSrcSAC: not in mapEvtLineageIndex" );
			int indexDest = mapEvtLineageIndex[ lineagesSrc[kkk].eidEnd ];
//cout << "indexDest = " << indexDest << endl;
			YW_ASSERT_INFO( indexDest < (int) listDestSACPops.size(), "Fail to get index222"  );
			vector<int> vecLinPopNew = listDestSACPops[indexDest];
			if( lineagesSrc[kkk].eidEnd ==  evtCoalDest )
			{
//cout << "At " << kkk << ", found a matching with diff2." << endl;
				YW_ASSERT_INFO( mapEvtLineageIndex.find( *(setDiff2.begin())  ) != mapEvtLineageIndex.end(), "Map fail to find" );
				int indexDestDiff = mapEvtLineageIndex[  *(setDiff2.begin())  ];
				YW_ASSERT_INFO( indexDestDiff>=0 && indexDestDiff<(int)listDestSACPops.size(), "Fail to get second index" );
				AddIntVec( vecLinPopNew, listDestSACPops[indexDestDiff] );

				// find which one get incremented and that is the one mutation occur
				for(int pppp=0; pppp<(int)vecLinPopNew.size(); ++pppp)
				{
					if( vecLinPopNew[pppp] != listDestSACPops[indexDest][pppp] )
					{
						YW_ASSERT_INFO(numMutBranchNum < 0, "Can only exist one with difference");
						numMutBranchNum = listDestSACPops[indexDest][pppp];
					}
				}
			}
			vecPopNumsSrc.push_back(  vecLinPopNew );
		}

		if( vecPopNumsSrc.size() == lineagesSrc.size() )
		{
			int idSrc = GetPartEnumIndex(vecMultiSrc, numSubPops, vecPopNumsSrc);
			result.vecSrcMutSACIds.push_back(idSrc);
			result.vecMutSzs.push_back( numMutBranchNum + 1);		// we add one to it
		}
	}

	YW_ASSERT_INFO( result.vecSrcCoalSACIds.size() == result.vecCoalSzs.size()
		&& result.vecSrcCoalSACIds.size() == result.vecCoalOrig.size(), "ObtainSrcSAC: output wrong1" );
	YW_ASSERT_INFO( result.vecSrcMutSACIds.size() == result.vecMutSzs.size(), "ObtainSrcSAC: output wrong2" );

	// now save the ids
//cout << "vecMultSrc: ";
//DumpIntVec( vecMultiSrc );
//cout << "vecpopnumsrc: ";
//DumpVecSequences(vecPopNumsSrc);
	//if( vecPopNumsSrc.size() == lineagesSrc.size() )
	//{
	//	int idSrc = GetPartEnumIndex(vecMultiSrc, numSubPops, vecPopNumsSrc);
	//	vecSrcSACIds.push_back( idSrc );
	//}
//cout << "*************************In ObtainSrcSAC, resuting src SAC id =: ";
//DumpIntVec( vecSrcSACIds );

	// get the id now
//	return pACSrc->GetSACId(lineagesSrc, vecPopNumsSrc);
}




double TreeACSubdivided :: GetProbAt( int t, int sacId )
{
	YW_ASSERT_INFO( t < RootedTreeACHelper::Instance().GetThetaNum() && 
		sacId < GetNumSACs(), "GetProbAt: out of range");
	return pProbValue[t][sacId];
}

void TreeACSubdivided :: SetProbAt(int t, int sacId, double prob)
{
	YW_ASSERT_INFO( t < RootedTreeACHelper::Instance().GetThetaNum() && 
		sacId < GetNumSACs(), "GetProbAt: out of range");
	pProbValue[t][sacId] = prob;
}


#if 0

int TreeACSubdivided :: GetSACId( const vector<COAL_LINEAGE> &lineages, const vector<int> &listPopSeqsNum )
{
	// 
	int res = 0;
	for(int i = 0; i<(int)lineages.size(); ++i)
	{
		if( i > 0 )
		{
			res = res*(lineages[i].multiplicity+1);
		}
		res += listPopSeqsNum[i];
	}
	return res;
}

bool TreeACSubdivided :: ConvSACIdToPopNumList(  const vector<COAL_LINEAGE> &lineages, int sacId, vector<int> &listPopSeqsNum )
{
	// 
	listPopSeqsNum.clear();
	int sacIdRem = sacId;
	for(int i= (int)lineages.size()-1; i>=0; --i)
	{
		int numCopies = lineages[i].multiplicity+1;
		YW_ASSERT_INFO( numCopies >=2, "Can not be zero" );
		int cid = ( sacIdRem % numCopies);
		listPopSeqsNum.push_back(cid);
		sacIdRem = (sacIdRem - cid)/numCopies;
	}
	// need to reverse it to match GetSACId
	ReverseIntVec( listPopSeqsNum );
	if( sacIdRem > 0)
	{
		return false;	// out of range
	}
	else
	{
		return true;	// within range
	}
}

int TreeACSubdivided :: ObtainSrcSAC( TreeACSubdivided *pACSrc, 
									 const vector<COAL_LINEAGE> &lineagesDest, const vector<int> &listDestSACPops )
{
cout << "ObtainSrcSAC: For pACSrc = ";
pACSrc->Dump();
cout << "listDestSACPops: ";
DumpIntVec( listDestSACPops );
	// get src lineages
	vector<COAL_LINEAGE> lineagesSrc;
	RootedTreeACHelper::Instance().GetCurrLineages(pACSrc->setACActiveEventIds, lineagesSrc);
cout << "ObtainSrcSAC: Current src lineages: \n";
for(int i=0; i<(int)lineagesSrc.size(); ++i)
{
lineagesSrc[i].Dump();
}
	set<int> setEvtsSrc;
	vector<int> vecEvtsSrc;
	for( int i=0; i<(int)lineagesSrc.size(); ++i )
	{
		setEvtsSrc.insert( lineagesSrc[i].eidEnd );
		vecEvtsSrc.push_back(lineagesSrc[i].eidEnd);
	}
cout << "ObtainSrcSAC: setEvtsSrc: ";
DumpIntSet( setEvtsSrc );
	// ensure there is no duplicate
	YW_ASSERT_INFO( setEvtsSrc.size() == lineagesSrc.size(), "ObtainSrcSAC: there is duplicate event in Src" );
	set<int> setEvtsDest;
	vector<int> vecEvtsDest;
	map<int,int> mapEvtPopNums;
	for( int i=0; i<(int)lineagesDest.size(); ++i )
	{
		setEvtsDest.insert( lineagesDest[i].eidEnd );
		vecEvtsDest.push_back( lineagesDest[i].eidEnd );
cout << "mapEvtPopNums: eidEnd = " << lineagesDest[i].eidEnd << ", multi = " << lineagesDest[i].multiplicity << endl;
		mapEvtPopNums.insert( map<int,int> :: value_type( lineagesDest[i].eidEnd, lineagesDest[i].multiplicity )  );
	}
cout << "ObtainSrcSAC: setEvtsDest: ";
DumpIntSet( setEvtsDest );
	YW_ASSERT_INFO( setEvtsDest.size() == lineagesDest.size(), "ObtainSrcSAC: there is duplicate event in Dest" );
	// 
	YW_ASSERT_INFO(lineagesDest.size() == lineagesSrc.size() || lineagesDest.size() == lineagesSrc.size()+1,
		"Lineages in Dest and Src not match");

	set<int> setDiff1 = setEvtsSrc;
	SubtractSets(setDiff1, setEvtsDest);
	YW_ASSERT_INFO( setDiff1.size() == 1, "ObtainSrcSAC: setDiff1 size wrong" );
	set<int> setDiff2 = setEvtsDest;
	SubtractSets(setDiff2, setEvtsSrc);
	YW_ASSERT_INFO( setDiff2.size() == 1, "ObtainSrcSAC: setDiff2 size wrong" );
cout << "Diff1: " << *(setDiff1.begin() ) << ", Diff2: " << *(setDiff2.begin()) << endl;


	vector<int> vecPopNumsSrc;
	if( lineagesDest.size() == lineagesSrc.size() )
	{
		// dest lineages are one more than src
		if( RootedTreeACHelper::Instance().IsEventCoalescent( *(setDiff2.begin() ) ) == true )
		{
cout << "ObtainSrcSAC: coalescent type\n";
			// coalescent event: avoid the diff1 one (which is ancestral to the new event)
			// by adding one more to the existing count
			for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
			{
cout << "lineagesSrc[kkk].eidEnd = " << lineagesSrc[kkk].eidEnd << endl;
				if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
				{
					// get the old id
					YW_ASSERT_INFO( mapEvtPopNums.find(lineagesSrc[kkk].eidEnd) != mapEvtPopNums.end(), 
						"ObtainSrcSAC: not in mapEvtPopNums" );
					vecPopNumsSrc.push_back( mapEvtPopNums[lineagesSrc[kkk].eidEnd]   );
				}
				else
				{
					YW_ASSERT_INFO(mapEvtPopNums[*(setDiff2.begin())]  >= 2, "ObtainSrcSAC: coal node in this case should have at least two");
					vecPopNumsSrc.push_back( mapEvtPopNums[*(setDiff2.begin())] -1 );
				}
			}
//cout << "vecPopNumsSrc: ";
//DumpIntVec( vecPopNumsSrc );

		}
		else
		{
//cout << "lineagesDest.size() == lineagesSrc.size(): mutation\n";
			//vector<int> posDiffDest;
			//GetVecPosNotInSet( vecEvtsDest, setEvtsSrc, posDiffDest );
			//YW_ASSERT_INFO( posDiffDest.size() == 1, "ObtainSrcSAC: posDiffDest.size is not one:" );
			//int posDestChange = posDiffDest[0];

			//vector<int> posDiffSrc;
			//GetVecPosNotInSet( vecEvtsSrc, setEvtsDest, posDiffSrc );
			//YW_ASSERT_INFO( posDiffSrc.size() == 1, "ObtainSrcSAC: posDiffSrc.size is not one:" );
			//int posSrcChange = posDiffSrc[0];

			// 
			for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
			{
				if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
				{
					// get the old id
					YW_ASSERT_INFO( mapEvtPopNums.find(lineagesSrc[kkk].eidEnd) != mapEvtPopNums.end(), 
						"ObtainSrcSAC: not in mapEvtPopNums" );
					vecPopNumsSrc.push_back( mapEvtPopNums[lineagesSrc[kkk].eidEnd]   );
				}
				else
				{
					vecPopNumsSrc.push_back( 1   );
				}
			}
		}
	}
	else
	{

cout << "ObtainSrcSAC: mutation type\n";

		// mutation event
		for( int kkk=0; kkk<(int)lineagesSrc.size(); ++kkk  )
		{
			if( lineagesSrc[kkk].eidEnd != *(setDiff1.begin()) )
			{
				// get the old id
				YW_ASSERT_INFO( mapEvtPopNums.find(lineagesSrc[kkk].eidEnd) != mapEvtPopNums.end(), 
					"ObtainSrcSAC: not in mapEvtPopNums" );
				if( lineagesSrc[kkk].eidEnd != *(setDiff2.begin()) )
				{
					vecPopNumsSrc.push_back( mapEvtPopNums[lineagesSrc[kkk].eidEnd]   );
				}
				else
				{
					YW_ASSERT_INFO(mapEvtPopNums[lineagesSrc[kkk].eidEnd]  >= 2, "ObtainSrcSAC: mutation node in this case should have at least two");
					vecPopNumsSrc.push_back( mapEvtPopNums[lineagesSrc[kkk].eidEnd] -1  );
				}
			}
			else
			{
				vecPopNumsSrc.push_back( 1   );
			}
		}
	}

	// get the id now
	return pACSrc->GetSACId(lineagesSrc, vecPopNumsSrc);
}

#endif



double TreeACSubdivided :: CalcProbDenom( const vector< vector<int> > &popDivId, double theta, 
										 const vector<double> &vecMigRateOut )
{
//cout << "CalcProbDenom: popDivId = ";
//DumpVecSequences(popDivId);
//cout << "theta = " << theta << endl;
//cout << "Migrate rates = ";
//DumpDoubleVec(vecMigRateOut);
	// here migrate out is = for each color, the combined probability of it change to SOME other color
	// which is the sum of the transition prob into some other color
	YW_ASSERT_INFO( popDivId.size() > 0, "CalcProbDenom: wrong");
	YW_ASSERT_INFO( vecMigRateOut.size() == popDivId[0].size(), "CalcProbDenom: wrong2");
	vector<int> vecSumPopSizes;
	for(int i=0; i<(int)vecMigRateOut.size(); ++i)
	{
		vecSumPopSizes.push_back(0);
	}
	int nTot = 0;
	for(int i=0; i<(int) popDivId.size(); ++i)
	{
		for(int j=0; j<(int)popDivId[i].size(); ++j)
		{
			vecSumPopSizes[j] += popDivId[i][j];
			nTot += popDivId[i][j];
		}
	}
//cout << "nTot = " << nTot << ", sumpopsizes = ";
//DumpIntVec( vecSumPopSizes );
	double res = 0.0;
	for( int i=0; i<(int)vecSumPopSizes.size(); ++i  )
	{
		if( vecSumPopSizes[i] >= 2)
		{
			double ratioPop = RootedTreeACHelper::Instance().GetEffectPopRatio(i);
			res += vecSumPopSizes[i]*(vecSumPopSizes[i]-1)/(2*ratioPop);
		}
		res += vecSumPopSizes[i]*vecMigRateOut[i];
	}
	res += nTot * theta/2;
//cout << "Final denom = " << res << ", Sum pop sizes = ";
//DumpIntVec(vecSumPopSizes);
	return res;
}

double TreeACSubdivided :: CalcCoalescentMutProbPart( double theta, const vector<int> &vecPopTotSz, const vector<int> &vecPopPartSz,
	const vector<int> &vecPopOrig, const vector<double> &vecPartProb, const vector<int> &vecMutSz, const vector<double> &vecMutProb,
	const vector< vector<int> > &enumPartsId) 
{
	YW_ASSERT_INFO( vecPopPartSz.size() == vecPartProb.size(), "CalcCoalescentMutProbPart: wrong");
	YW_ASSERT_INFO( vecPopPartSz.size() == vecPopOrig.size(), "CalcCoalescentMutProbPart: wrong1");
	YW_ASSERT_INFO( vecMutSz.size() == vecMutProb.size(), "CalcCoalescentMutProbPart: wrong2");

	if(vecPopPartSz.size() == 0 && vecMutSz.size() == 0)
	{
//cout << "enumPartsId = ";
//DumpVecSequences( enumPartsId );

		// if not a starting state, and no reachable event, then just return 0
		if( this->setACActiveEventIds.size() > 1  )
		{
			return 0.0;
		}

		// This must be the initial AC
		YW_ASSERT_INFO( this->setACActiveEventIds.size() == 1 &&
			(*setACActiveEventIds.begin()) == 0, "InitStartingProb: only work with the starting AC" );
		YW_ASSERT_INFO( enumPartsId.size() == 1, "CalcCoalescentMutProbPart: wrong2");
		int nPopOfTwo = -1;
		for(int i=0; i<(int) enumPartsId[0].size(); ++i)
		{
			if( enumPartsId[0][i] == 2 )
			{
				nPopOfTwo = i;
				break;
			}
		}
//cout << "nPopOfTwo = " << nPopOfTwo << endl;
		if( nPopOfTwo < 0 )
		{
			return 0.0;
		}
		else
		{
			double ratioPop = RootedTreeACHelper::Instance().GetEffectPopRatio( nPopOfTwo  );
			//vector<int> emptyEvt;
			//TreeACSubdivided acZero( emptyEvt );		// find how the prob is nitialized
//cout << "ratioPop: " << ratioPop << endl;
			// TBD. temp hack
			//return 2.0;
			// note: init prob of a absorbing state is 1 (why not 0.5??)
			//return 1.0*GetInitProb( nPopOfTwo )/ratioPop;
			return 1.0/ratioPop;
		}
	}


	double res = 0.0;

	// add up coalesce prob
	for(int i=0; i<(int)vecPopPartSz.size(); ++i)
	{
		YW_ASSERT_INFO( vecPopOrig[i] < RootedTreeACHelper::Instance().GetSubPopulationNum(), "vecPopOrig: out of bound" );
		double ratioPop = RootedTreeACHelper::Instance().GetEffectPopRatio( vecPopOrig[i]  );
		YW_ASSERT_INFO( vecPopPartSz[i] >=2, "vecPopPartSz: size should be at least 2" );
		res += vecPartProb[i]*vecPopTotSz[vecPopOrig[i] ]*(vecPopPartSz[i]-1)*0.5/ratioPop;
	}
	// add up mutation prob
	for(int i=0; i<(int)vecMutSz.size(); ++i)
	{
		res += 0.5*theta*vecMutSz[i]*vecMutProb[i];
	}

	return res;
}

void TreeACSubdivided :: FindMigNgbrs( const vector<vector<int> > &partEnumId, vector<double> &vecMigFactors, vector<int> &vecSACIds )
{
	// 
	vecMigFactors.clear();
	vecSACIds.clear();

	// multiplicity for each color
	YW_ASSERT_INFO(partEnumId.size() > 0 && partEnumId[0].size() > 0, "FindMigNgbrs: wrong in partenumid");
	vector<int> vecMultiPerColor(partEnumId[0].size());
	for(int i=0; i<(int)vecMultiPerColor.size(); ++i)
	{
		vecMultiPerColor[i] = 0;
	}


	// multiplicity of each part (with all sub-pops
	vector<int> vecMulticities;
	for( int i=0; i<(int)partEnumId.size(); ++i )
	{
		int nmulti = 0;
		for(int j=0; j<(int)partEnumId[i].size(); ++j)
		{
			nmulti += partEnumId[i][j];
			vecMultiPerColor[j] += partEnumId[i][j];
		}
		vecMulticities.push_back( nmulti );
	}

	// find which segment has non-zeros
	for(int i=0; i<(int)partEnumId.size(); ++i)
	{
		for(int j=0; j<(int)partEnumId[i].size(); ++j)
		{
			//
			if( partEnumId[i][j] > 0)
			{
				// no change to types, only count of the current lineage
				// so if it has P items in this lineage, we will have P sub-ACs touched
				for(int k=0; k<(int)partEnumId[i].size(); ++k)
				{
					if( k != j)
					{
						vector<vector<int> > partEnumIdNew = partEnumId;
						partEnumIdNew[i][j] --;
						partEnumIdNew[i][k] ++;
						int eindex = GetPartEnumIndex(vecMulticities, RootedTreeACHelper::Instance().GetSubPopulationNum(), 
							partEnumIdNew);

						// save this id
						vecSACIds.push_back( eindex );

						// figure out prob of this migration
						double probMig = partEnumIdNew[i][k]* RootedTreeACHelper::Instance().GetMigrationRate(j, k)
							*1.0*vecMultiPerColor[j]/(1+vecMultiPerColor[k] );
						vecMigFactors.push_back(probMig);
					}
				}
			}
		}
	}
}


void TreeACSubdivided :: SolveLinearEquations( int n, int *Ap, int *Ai, double *Ax, double *b,  double *sol )
{
	UMFPACKSolveLinearEquations(n, Ap, Ai, Ax, b, sol);
#if 0
	// solve square matrix
	double *null = (double *) NULL ;
	int i ;
	void *Symbolic, *Numeric ;
	(void) umfpack_di_symbolic (n, n, Ap, Ai, Ax, &Symbolic, null, null) ;
	(void) umfpack_di_numeric (Ap, Ai, Ax, Symbolic, &Numeric, null, null) ;
	umfpack_di_free_symbolic (&Symbolic) ;
	(void) umfpack_di_solve (UMFPACK_A, Ap, Ai, Ax, sol, b, Numeric, null, null) ;
	umfpack_di_free_numeric (&Numeric) ;
	for (i = 0 ; i < n ; i++) printf ("sol [%d] = %g\n", i, sol [i]) ;
#endif
}


void TreeACSubdivided :: CalcMigStatesProb(vector< vector< int> > &vecFirstSACIndex,
	vector<  vector<double> > &vecFirstSACCoeff,
	vector< vector<int> > &vecRelatedSACIndex,
	vector< vector<double> > &vecRelatedSACCoeffs,
	vector< vector<double> > &vecRHS)
{
//cout << "CalcMigStatesProb: vecFirstSACIndex = ";
//DumpIntVec( vecFirstSACIndex[0] );
//for(int i=0; i<(int)vecFirstSACCoeff.size(); ++i)
//{
//DumpDoubleVec( vecFirstSACCoeff[i] );
//}
//for(int i=0; i<(int)vecRelatedSACIndex.size();++i)
//{
//cout << "vecRelatedSACIndex: ";
//DumpIntVec( vecRelatedSACIndex[i] );
//cout << "vecRelatedSACCoeffs: ";
//DumpDoubleVec(vecRelatedSACCoeffs[i] );
//}
//cout << "RHS: \n";
//for(int i=0; i<(int)vecRHS.size(); ++i)
//{
//DumpDoubleVec( vecRHS[i] );
//}

	YW_ASSERT_INFO( (int)vecFirstSACIndex.size() == RootedTreeACHelper::Instance().GetThetaNum(), "CalcMigStatesProb: size wrong" );
	int numt = vecFirstSACIndex.size();
	int n = vecFirstSACIndex[0].size();
//cout << "numt = " << numt << ", n = " << n << endl;
	// solve an equation list and update the probility of all sub-AC states
	// first figure out the compressed column format (from the row format)
	// caution: has to be sorted
	int numNonZerpPos = 0;
	for(int i=0; i<(int)vecRelatedSACIndex.size(); ++i)
	{
		numNonZerpPos += 1;		// the src mig state
		numNonZerpPos += vecRelatedSACIndex[i].size();
	}
//cout << "numNonZerpPos: " << numNonZerpPos << endl;
	vector< vector<vector<int> > > vecCCFIndexList(numt);
	vector< vector< vector<double> > > vecCCFCoeffList(numt);
	for(int i=0; i<(int)vecFirstSACIndex.size(); ++i)
	{
//cout << "i = " << endl;
		vecCCFIndexList[i].resize(n);
		vecCCFCoeffList[i].resize(n);
		for(int j=0; j<(int)vecFirstSACIndex[i].size(); ++j)
		{
			int pos = vecFirstSACIndex[i][j];
//cout << "j: " << j << ", pos = " << pos <<endl;
			vecCCFIndexList[i][pos].push_back( j );
			vecCCFCoeffList[i][pos].push_back( vecFirstSACCoeff[i][j] );

			// now set up migration
			for(int kk=0; kk<(int)vecRelatedSACIndex[j].size(); ++kk)
			{
				pos = vecRelatedSACIndex[j][kk];

				vecCCFIndexList[i][pos].push_back( j );
				vecCCFCoeffList[i][pos].push_back( -1.0*vecRelatedSACCoeffs[j][kk] );
			}
		}
	}


//cout << "After conversion: vecCCFIndexList[0]=\n";
//for(int i=0; i<(int)vecCCFIndexList[0].size(); ++i)
//{
//DumpIntVec( vecCCFIndexList[0][i] );
//}
//cout << "vecCCFCoeffList (for each theta): \n";
//for(int i=0; i<(int)vecCCFCoeffList.size();++i)
//{
//cout << "t = " << i << endl;
//for(int j=0; j<(int)vecCCFCoeffList[i].size(); ++j )
//{
//DumpDoubleVec(vecCCFCoeffList[i][j] );
//}
//}

	// Ap: the same for all theta
	YW_ASSERT_INFO( vecRelatedSACIndex.size() == vecRelatedSACCoeffs.size(), "CalcMigStatesProb: size wrong1" );
	int *Ap = (int *)malloc( (n+1)*sizeof(int) );
	int *Ai = (int *)malloc( numNonZerpPos*sizeof(int)  );

	// init Ap
	int pcurr = 0;
	for(int i=0; i<(int)vecFirstSACIndex[0].size(); ++i)
	{
		Ap[i] = pcurr;

		//
		for(int j=0; j<(int)vecCCFIndexList[0][i].size(); ++j)
		{
			Ai[pcurr + j] = vecCCFIndexList[0][i][j];
		}

		pcurr += vecCCFIndexList[0][i].size();
	}
	Ap[n] = pcurr;
//cout << "Ap: ";
//DumpIntArray(n+1, Ap);
//cout << "Ai: ";
//DumpIntArray(numNonZerpPos, Ai);

	// allocate more
	double *Ax = (double *)malloc( numNonZerpPos*sizeof(double) );
	double *b = (double *)malloc( n*sizeof(double)  );
	double *sol = (double *)malloc( n*sizeof(double) );

	// for each theta now
	for(int t=0; t<numt; ++t)
	{
		//= {0, 2, 5, 9, 10, 12} ;
		//int    Ai [ ] = { 0,  1,  0,   2,  4,  1,  2,  3,   4,  2,  1,  4} ;
		//double Ax [ ] = {2., 3., 3., -1., 4., 4., -3., 1., 2., 2., 6., 1.} ;
		//double b [ ] = {8., 45., -3., 3., 19.} ;
		//double x [5] ;

		// setup Ax
		int pos= 0;
		for(int i=0; i<(int)vecCCFIndexList[t].size(); ++i)
		{
			for(int j=0; j<(int)vecCCFIndexList[t][i].size(); ++j)
			{
				Ax[pos++] = vecCCFCoeffList[t][i][j];
			}
		}

		for(int i=0; i<n; ++i)
		{
			b[i] = vecRHS[t][i];
		}

		UMFPACKSolveLinearEquations(n, Ap, Ai, Ax, b, sol);

		// now setup the value for all subAC here
		for(int i=0; i<n; ++i)
		{
			SetProbAt(t, i, sol[i] );
		}
	
	}

//cout << "After solving equations, the AC becomes: ";
//this->Dump();

	// release buffer
	free(Ap);
	free(Ai);
	free(Ax);
	free(b);
	free(sol);
}

void TreeACSubdivided :: InitStartingProb()
{
	// setup the starting AC (with a single event 0):
	YW_ASSERT_INFO( this->setACActiveEventIds.size() == 1 &&
		(*setACActiveEventIds.begin()) == 0, "InitStartingProb: only work with the starting AC" );

	// create a simple AC with empty events?
	//vector<int> emptyEvt;
	//TreeACSubdivided acZero( emptyEvt );
	// ???
	//this->Aggregate( &acZero );
	CalcSACProbs();
//cout << "After InitStartingProb:, updated AC: ";
//this->Dump();
}

double TreeACSubdivided :: GetInitProb(int nPopIndex)
{
	// for now, no matter what nPop it is, same prob???
	// in fact, a simple calculation suggests this is always true no matter what migration rate is
	int numSubPop = RootedTreeACHelper::Instance().GetSubPopulationNum();
	return 1.0/numSubPop;
}


//////////////////////////////////////////////////////////////////////////////////////////////
// exploring other???


SubdividedRTreeACExplorer :: SubdividedRTreeACExplorer(BinaryMatrix &mat, SEQUENCE &seqR, const vector<int> &listPLIn)
  :RootedTreeACExplorer(mat, seqR), listPopLabels(listPLIn)
{
	YW_ASSERT_INFO( (int)listPLIn.size() == mat.GetRowNum(), "Population label number does not match input matrix" );
}


TreeAC * SubdividedRTreeACExplorer :: CreateAC(const vector<int> &initEvts) 
{ 
	return new TreeACSubdivided(initEvts); 
}

void SubdividedRTreeACExplorer :: Explore()
{
	// explore 
	RootedTreeACExplorer :: Explore();
//cout << "Now find the current solution\n";
	YW_ASSERT_INFO(pCurrACDepot != NULL, "pCurrACDepot is NULL\n");
	// find lineages
	YW_ASSERT_INFO( pCurrACDepot->GetNumACs() == 1, "The depot should have a single starting AC" );
	TreeACDepotIterator itor;
	pCurrACDepot->GetTreeACIterator( itor );
	TreeAC *pAC = itor.GetCurrItem();
	TreeACSubdivided *pACSub = dynamic_cast<TreeACSubdivided *>(pAC);
	YW_ASSERT_INFO( pACSub != NULL, "Wrong type of ACs" );

	vector<int> evtIdFinalAC;
	pACSub->GetCurrEvtIds(evtIdFinalAC);
//cout << "evtIdFinalAC: ";
//DumpIntVec( evtIdFinalAC );
	vector<COAL_LINEAGE> lineages;
	RootedTreeACHelper::Instance().GetCurrLineages(evtIdFinalAC, lineages);
//cout << "Final lineages: \n";
//for(int i=0; i<(int)lineages.size(); ++i)
//{
//lineages[i].Dump();
//}
	// setup pop seqs
	vector< vector<int> > enumIdFinal( lineages.size()  );
	for(int i=0; i<(int)lineages.size(); ++i)
	{
		for(int j=0; j<RootedTreeACHelper::Instance().GetSubPopulationNum(); ++j)
		{
			enumIdFinal[i].push_back( 0 );
		}
	}

	// find out which lineage this is:
	set<int> setMutSites[lineages.size()];
	for(int j=0; j<(int)lineages.size(); ++j)
	{
		vector<int> mutSites;
		RootedTreeACHelper::Instance().GetMutEvtsForLineage(lineages[j].eidEnd, mutSites);
//cout << "Lineage " << j << " mut sites = ";
//DumpIntVec( mutSites );
		PopulateSetByVec( setMutSites[j], mutSites );
	}
	
	// now treat each sequence
	for(int r=0; r<matInput.GetRowNum(); ++r)
	{
		SEQUENCE row;
		matInput.GetRow(r, row);
		set<int> mutSitesCol;
		GetMutSitesFromRoot( row, mutSitesCol ); 
		// need to convert into mutation id used
		set<int> mutSites;	
		for(set<int> :: iterator it = mutSitesCol.begin(); it != mutSitesCol.end(); ++it)
		{
			mutSites.insert( RootedTreeACHelper::Instance().GetMutationId(*it) );
		}
//cout << "Row " << r << ", row = ";
//DumpSequence(row);
//cout << "row mutSites = ";
//DumpIntSet( mutSites );
		int linIndex = -1;
		for(int j=0; j<(int)lineages.size(); ++j)
		{
			if( setMutSites[j] == mutSites )
			{
				YW_ASSERT_INFO( linIndex < 0, "Two matches. ERROR" );
				linIndex = j;
				//break;
			}
		}
		YW_ASSERT_INFO( linIndex >= 0, "Fail to find the lineage" );
		// 
		int popLabel = listPopLabels[r];
//cout << "popLabel = " << popLabel << ", linIndex = " << linIndex << endl;
		enumIdFinal[linIndex][ popLabel-1 ] ++;
	}

//cout << "Population label of the input config = \n";
//DumpVecSequences( enumIdFinal );

	vector<int> vecMulticities;
	for(int i=0; i<(int)lineages.size(); ++i)
	{
		vecMulticities.push_back(lineages[i].multiplicity );
	}
	int sacId = GetPartEnumIndex(vecMulticities, RootedTreeACHelper::Instance().GetSubPopulationNum(), enumIdFinal);
//cout <<"Input config final sacid = " << sacId << endl;

	for(int t=0; t<RootedTreeACHelper::Instance().GetThetaNum(); ++t)
	{
		cout << "Likelihood value for theta = " << RootedTreeACHelper::Instance().GetTheta(t) << "      " << pACSub->GetProbAt(t, sacId) << endl;
	}
	// print out the final solution corresponding to the solution
	//int sacid = ;
}


void SubdividedRTreeACExplorer :: UpdateExplore()
{
	// calculate prob. for each AC
	TreeACDepotIterator itor;
	pNextACDepot->GetTreeACIterator( itor );
	while( itor.IsDone() == false )
	{
		TreeAC *pAC = itor.GetCurrItem();
		itor.Next();
		TreeACSubdivided *pACSub = dynamic_cast<TreeACSubdivided *>(pAC);
		YW_ASSERT_INFO( pACSub != NULL, "Wrong type of ACs" );

		pACSub->CalcSACProbs();
	}


	// then call whatever to do as before
	RootedTreeACExplorer :: UpdateExplore();
}

void SubdividedRTreeACExplorer :: InitExplore()
{
	// call super's first
	RootedTreeACExplorer :: InitExplore();

	// get the (only) AC in depot and init
	YW_ASSERT_INFO( pCurrACDepot->GetNumACs() == 1, "The depot should have a single starting AC" );
	TreeACDepotIterator itor;
	pCurrACDepot->GetTreeACIterator( itor );
	TreeAC *pAC = itor.GetCurrItem();
	TreeACSubdivided *pACSub = dynamic_cast<TreeACSubdivided *>(pAC);
	YW_ASSERT_INFO( pACSub != NULL, "Wrong type of ACs" );
	pACSub->InitStartingProb();

}

void SubdividedRTreeACExplorer :: GetMutSitesFromRoot( const SEQUENCE &seq, set<int> &mutSites )
{
	// Note: convention:
	// if seqRoot is not set, then it is all-0
	YW_ASSERT_INFO( seqRoot.size() == 0 || seq.size() == seqRoot.size(), "Either seq or seqRoot size is wrong" );

	for(int i=0; i<(int)seq.size(); ++i)
	{
		if( seqRoot.size() == 0 )
		{
			if( seq[i] != 0 )
			{
				mutSites.insert(i);
			}
		}
		else if( seqRoot[i] != seq[i] )
		{
			mutSites.insert(i);
		}
	}
}


