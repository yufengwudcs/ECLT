#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>

#include <sys/types.h>
#include <time.h>
#include <unistd.h>
using namespace std;

#include <cmath>
#include "SNPUtils.h"
#include "BinaryMatrix.h"
#include "Utils3.h"
#include "TreeCfgExplorer.h"
#include "TreeCfgExpSubdivided.h"


/////////////////////////////////////////////////////////////////////////////
// Global variables

//static int numARGsToSample = 10;
static int fileArgIndex = 1;
static bool fUniform = false;
static double thetaCfg = 1.0;
static bool fTopoConstraint = false;
static bool fRootSet = false;
static bool fRootSetToZeros = false;
static vector<int> knownRoot;
static int numSamplesToDraw = 100;
static bool fFullLikelihoodMode = false;
static bool fPopIdentity = false;
static string filePopIdentity;
static int numSubPopulations = 1;
static double migRateSym = 1.0;
static bool fOutGenetreeOnly = false;
static string fileOutGenetree = "tmpColorGTree.dat";


static void Usage()
{
    cout << "Usage: ECLT <OPTIONS> <file-name>";
    cout << "See Readme file\n";
    exit(1);
}


static bool CheckArguments(int argc, char **argv) 
{
    if( argc <= 1  /*|| argc >= 8*/)
    {
        return false;
    }
    if( argc == 2)
    {
        fileArgIndex = 1;
    }
    else 
    {
        // Check argument one by one
        for(int i = 1; i< argc; ++i)
        {
		    if(strncmp ( argv[i], "-t", 2) == 0)
            {
                // Then it means to set theta
				float theta;
	            sscanf(argv[i]+2, "%f", &theta );
				thetaCfg = theta;

				// set tree config too
				RootedTreeACHelper::Instance().SetThetaBegin( theta);
				RootedTreeACHelper::Instance().SetThetaNum( 1 );

				cout << "Set theta = " << theta << endl;
            }
		    else if(strncmp ( argv[i], "-st", 3) == 0)
            {
                // Then it means to set theta
				float theta;
	            sscanf(argv[i]+3, "%f", &theta );
//				TwoStageARGSampler::SetTheta( theta );

				// set tree config too
				RootedTreeACHelper::Instance().SetThetaBegin( theta);
				RootedTreeACHelper::Instance().SetThetaNum( 1 );

				cout << "Set theta to begin at " << theta << endl;
            }
		    else if(strncmp ( argv[i], "-it", 3) == 0)
            {
                // Then it means to set theta
				float thetaInc;
	            sscanf(argv[i]+3, "%f", &thetaInc );
//				TwoStageARGSampler::SetTheta( theta );

				// set tree config too
				RootedTreeACHelper::Instance().SetThetaInc( thetaInc);

				cout << "Set theta inc to  " << thetaInc << endl;
            }
		    else if(strncmp ( argv[i], "-nt", 3) == 0)
            {
                // Then it means to set theta
				int numInc;
	            sscanf(argv[i]+3, "%d", &numInc );
//				TwoStageARGSampler::SetTheta( theta );

				// set tree config too
				RootedTreeACHelper::Instance().SetThetaNum( numInc );

				cout << "Set theta number to " << numInc << endl;
            }

		    else if(strncmp ( argv[i], "-T", 2) == 0)
            {
                // Then limit the number of ACs to keep
				int numACs;
	            sscanf(argv[i]+2, "%d", &numACs ); 
cout << "Setting number of ACs to keep: " << numACs << endl;
				SetACKeepLimit( numACs  );
            }
		    else if(strncmp ( argv[i], "-U", 2) == 0)
            {
                // Then limit the number of ACs to keep
cout << "Turn on full likelihood computaton..." << endl;
				fFullLikelihoodMode = true;
			}
			else if(strncmp ( argv[i], "-C", 2) == 0)
			{
cout << "Turn on topologically constrained sampling..." << endl;
				fTopoConstraint = true;
			}
			else if(strncmp ( argv[i], "-R", 2) == 0)
			{
				for( int c=2; c<(int)strlen(argv[i]); ++c )
				{
					if( argv[i][c] == '0')
					{
						knownRoot.push_back(0);
					}
					else if( argv[i][c] == '1' )
					{
						knownRoot.push_back(1);
					}
					else
					{
						YW_ASSERT_INFO(false, "root must be binary");
					}
				}
cout << "Set root to ";
DumpSequence( knownRoot );
				fRootSet = true;
			}
			else if( strncmp ( argv[i], "-N", 2) == 0 )
			{
	            sscanf(argv[i]+2, "%d", &numSamplesToDraw );

				cout << "Number of samples to draw = " << numSamplesToDraw << endl;
			}
			else if(  strncmp ( argv[i], "-Z", 2) == 0  )
			{
				cout << "Set root to all-zeros.\n";
				fRootSetToZeros = true;
			}
			else if(strncmp ( argv[i], "-p", 2) == 0)
			{
				fPopIdentity = true;
				YW_ASSERT_INFO( i < argc-2, "Miss the file after the flag" );
				i++;
	            sscanf(argv[i], "%d", &numSubPopulations );
				i++;	// point to next position
				filePopIdentity = argv[i];
cout << "Number of subpopulations = " << numSubPopulations << endl;
cout << "Turn on subdivided mode: populaton label file = " << filePopIdentity << endl;
			}
			else if(strncmp ( argv[i], "-m", 2) == 0)
			{
				YW_ASSERT_INFO( i < argc-1, "Miss the file after the flag" );
				i++;
				float ftmp;
//cout << "argv[i] = " << argv[i] << endl;
	            sscanf(argv[i], "%f", &ftmp );
				migRateSym = ftmp;
cout << "Symetric migration rate is set to " << migRateSym << endl;
			}
			else if(strncmp ( argv[i], "-gt", 3) == 0 )
			{
				YW_ASSERT_INFO( i < argc-1, "Miss the outfile name after -gt flag" );
				i++;
				fileOutGenetree = argv[i];				
cout << "Only output genetree format to: " << fileOutGenetree << endl;
				fOutGenetreeOnly = true;
			}

			else if( argv[i][0] != '-' )
			{
				// not an option one. Right now the only one is file
				fileArgIndex = i;
			}

            else
            {
                return false;
            }
        }
    }
    return true;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// testing function



const int MAX_NUM_RECURSE_LIMIT = 100;

static void RunTreeExplorer(BinaryMatrix &mat)
{
	if( mat.GetColNum() + mat.GetRowNum() >= MAX_NUM_RECURSE_LIMIT )
	{
		// can not proceed
	//	return;
	}

	// before doing anything, make all-0 the major sequence (if root is not set)
	if( fRootSet == false && fRootSetToZeros == false )
	{
		mat.ConfigZeroMajSeq();
cout << "After zeroing major sequence, the new matrix = " ;
mat.Dump();
	}

	// also try to see how much we can trim the data
//	BinaryMatrix trimMat = mat;
//	cout << "Multiplicity of the matrix is: ";
//	mat.DumpRowMultiplicity();
	OutputGeneTreeMatrix( mat, "tmp-Genetree.dat");


	//const double theta = 2.0;
	//double theta = GetTheta();
	//RootedTreeACHelper::Instance().SetTheta( theta);
//	cout << "Set theta to " << 	RootedTreeACHelper::Instance().GetTheta( ) << endl;

	// explore it
	SEQUENCE rootToUse;
	if( fRootSet == true)
	{
		rootToUse = knownRoot;
	}
	else if( fRootSetToZeros == true )
	{
		// set the all-zero one to root
		for( int c=0; c<mat.GetColNum(); ++c )
		{
			rootToUse.push_back(0);
		}
		cout << "Use all-zero root: ";
		DumpSequence( rootToUse);
	}
	RootedTreeACExplorer rtACExplorer(mat, rootToUse);
	if( fRootSet == true )
	{
		rtACExplorer.SetRoot(knownRoot);
	}
	rtACExplorer.Explore();
}

void RunColoredTreeExplorer(BinaryMatrix &mat)
{
	YW_ASSERT_INFO( filePopIdentity.size() > 0, "Population label file missing" );


	// before doing anything, make all-0 the major sequence (if root is not set)
	if( fRootSet == false && fRootSetToZeros == false )
	{
		mat.ConfigZeroMajSeq();
cout << "After zeroing major sequence, the new matrix = " ;
mat.Dump();
		fRootSetToZeros = true;
	}

	// read in the labeleing
	vector<int> listPopLabels;
	//ifstream file( filePopIdentity.c_str() );
	//while( file.eof() == false )
	//{
	//	int val;
	//	file >> val;
	//	listPopLabels.push_back( val );
	//}
	ReadIntListFromFile( filePopIdentity.c_str(), listPopLabels );
cout << "Population label: ";
DumpIntVec( listPopLabels );
	YW_ASSERT_INFO( (int)listPopLabels.size() == mat.GetRowNum(), "Population label number does not match sequence number");

	//
	OutputGeneTreeMatrixStruct( mat, fileOutGenetree.c_str(), listPopLabels);
	if( fOutGenetreeOnly == true )
	{
		return;
	}


	// setup pop number
	YW_ASSERT_INFO(numSubPopulations == 2, "Only support two population right now");
	RootedTreeACHelper::Instance().SetSubPopulationNum(numSubPopulations);
	vector<vector<double> > vecMigRates(2);
	vecMigRates[0].push_back(0.0);
	vecMigRates[0].push_back( migRateSym );
	vecMigRates[1].push_back(migRateSym );
	vecMigRates[1].push_back(0.0);
	RootedTreeACHelper::Instance().SetMigrationRates(vecMigRates);

	// 
	// explore it
	SEQUENCE rootToUse;
	if( fRootSet == true)
	{
		rootToUse = knownRoot;
	}
	else if( fRootSetToZeros == true )
	{
		// set the all-zero one to root
		for( int c=0; c<mat.GetColNum(); ++c )
		{
			rootToUse.push_back(0);
		}
		cout << "Use all-zero root: ";
		DumpSequence( rootToUse);
	}
//cout << "Root to use: ";
//DumpSequence( rootToUse);
	SubdividedRTreeACExplorer rtACExplorer(mat, rootToUse, listPopLabels);
	if( fRootSet == true )
	{
		rtACExplorer.SetRoot(knownRoot);
	}
	rtACExplorer.Explore();
}


int main(int argc, char **argv)
{

    if( CheckArguments( argc, argv) == false)
    {
        Usage();
    }

	// data input
	ifstream inFile(argv[fileArgIndex]);
	if(!inFile)
	{
		cout << "Can not open "<< argv[fileArgIndex] <<endl;
		exit(1);
	}

    BinaryMatrix inputMat;
    inputMat.ReadFromFile (inFile );
    inFile.close();
//cout << "Read matrix = ";
//inputMat.Dump();

//cout << "fileArgIndex = " << fileArgIndex << endl;
    // Now read in SNP position, with the same SNP distance info
    if( SNPDefaultDistInfo.ReadFromFile( argv[fileArgIndex] ) == false )
    {
        cout << "Warning: no SNP positions are read. Use default instead.\n";
        //SNPDefaultDistInfo.InitDefaultDistance( inputMat.GetColNum()  );
		YW_ASSERT_INFO(false, "The program needs the site locaton to continue.");
    }
    // make sure the SNP number makes sense
    YW_ASSERT_INFO( SNPDefaultDistInfo.GetSNPNum() == inputMat.GetColNum() , "SNP number is wrong."  );



	// keep time
    long tstart1 = GetCurrentTimeTick();

	if( fPopIdentity == true )
	{
		RunColoredTreeExplorer( inputMat );
	}
	else
	{

	// do stuff
	// test function
		RunTreeExplorer( inputMat );
	}

    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;

    // for now, do nothing
    return 0;
}
