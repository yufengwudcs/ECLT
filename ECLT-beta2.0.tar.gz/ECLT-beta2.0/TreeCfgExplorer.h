#ifndef TREE_CFG_EXPLORER_H
#define TREE_CFG_EXPLORER_H

#include "Utils3.h"
#include "BinaryMatrix.h"
#include <vector>
#include <set>
#include <map>
using namespace std;


// exploring infinite-site-model AC (ancestral config) space
// Different from previous work, we take a FORWARD looking idea

void SetACKeepLimit(int limit);
void OutputGeneTreeMatrix( BinaryMatrix &mat, char *filename );
void OutputGeneTreeMatrixStruct( BinaryMatrix &mat, const char *filename, const vector<int> &popLabels );
void SetACAbortLimit(int limit);
int GetACAbortLimit();


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree config
// if empty, it means the single ancestral sequence


class TreeAC
{
public:
	// more?
	virtual int GetNumSeqs() = 0;	// = num of coalescent + 1 
	virtual  bool IsSame( TreeAC *pAC ) = 0;
	virtual void GetNextACs( vector<TreeAC *> &listNewACs ) = 0;
	virtual void Dump() = 0;
	virtual void AddActiveEvent(int evid ) = 0;
	virtual void Consolidate() = 0;
	virtual  int GetSignature( ) = 0;  // useful in hashing
	virtual double GetProb(int index) = 0;
	virtual void UpdateByCoalescent( int numSeq, int numCoalSeq ) = 0;
	virtual void UpdateByMutation( int numSeq, int numMutSeq  ) = 0;
	virtual void Aggregate( TreeAC *pAC ) = 0;
	virtual double GetEstProbRemain() = 0;
	virtual int GetNumCurEvts() = 0;
};


class TreeACPanmictic : public TreeAC
{
public:
	TreeACPanmictic(const vector<int> &initEvts);
	TreeACPanmictic( const TreeACPanmictic &rhs);
	virtual ~TreeACPanmictic();

	// more?
	int GetNumSeqs();	// = num of coalescent + 1 
	bool IsSame( TreeAC *pAC );
	void GetNextACs( vector<TreeAC *> &listNewACs );
	void Dump();
	void AddActiveEvent(int evid );
	void Consolidate();
	int GetSignature( );  // useful in hashing
	double GetProb(int index) {return pProbValue[index];}
	void UpdateByCoalescent( int numSeq, int numCoalSeq );
	void UpdateByMutation( int numSeq, int numMutSeq  );
	void Aggregate( TreeAC *pAC );
	double GetEstProbRemain();
	int GetNumCurEvts() {return this->setACActiveEventIds.size();}

private:
	bool IsSamePanmictic( TreeACPanmictic *pAC );
	void UpdateNextEvents( int eid, set<int> &setNextEvents );
//	void FillCharSet( set<char> &sc, const vector<int> &veci );
	int GetIdsSum();
//	void PopulateVecByTemp() { PopulateVecBySet(setACActiveEventIds, pSetTempIds); delete pSetTempIds; }
//	int CalcHashVal();
//	int GetSimpleHash();
//	void CalcSimpleHash();


	// represnted as simply a set of event indices
	// can be coalesence or mutation. 
	// Note, each mutation is unique, but sometimes coal. can be subsituted for each other
	// active means the descendents not finished yet
	vector<int> setACActiveEventIds;
//	set<int> setACDeadEventIds;			// these nodes are finished: no need to explore

	// each AC has a set of events to go next
	//set<char> setNextEvents;

	// value of the AC
	double *pProbValue;
	//set<int> *pSetTempIds;
	//int hashVal;
	//int hashVal2;
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree config helper for explore purpoose
// Assume: all-0 sequence as tree root
// Caution: care should be taken at multifuricated tree node:
// e.g. suppose the out-degree is 4 (i.e. 3 coalescent events, named as a,b,c)
// and there are x,y,z,w events (mutation or coal) for each outgoing 
// Then a is always the first, followed by b and c last
// each time, if say x follows a, then the next can NOT be y,z,w!
// instead, either we continue to explore at x down, OR we have to
// introduce b. Another way is to avoid 
// IN GENERAL: only the last (c in this case) can choose
// two. 

// recordiing at each node of perfect phylogeny
// the constraints at the root
class RTACNodeInfo
{
public:
	RTACNodeInfo(int cid, int numCoals);
	virtual ~RTACNodeInfo() {}
	// use -1 to indicate leaf reached
	void AddBranch( const set<int> &branchEvents, int coalEnd );
	// get next possible events
	void GetNextEvents( set<int> &curEvts, set<int> &nextEvts  );
	virtual void GetNextEventsFor( int evtJustAdd, const set<int> &curEvts, set<int> &nextEvts, set<int> &evtToRemove );
	void GetCurCoalNodes(set<int> &nodes);
	inline void GetCurMutNodes(set<int> &nodes);
	int GetCurMutsBranchNum( const set<int> &nodes);
	int GetNumLocalCoalescents() { return numCoalsNode; }
	int GetLeadCoalescentId() { return cidStart; }
	void GetAllLocalEvents( set<int> &evtSet, set<int> &evtNoUnderCoal ) { evtSet = setAllLocalEvents; evtNoUnderCoal = setLocalEveentsNoUnderCoals; }
	bool IsCoalEvtInRange(int eid ) {return eid >= cidStart && eid <= cidStart+numCoalsNode-1;}
	inline int GetLocalCoalNum(int coalid);				// get coalescent id
	virtual int GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr);		// get how many branches can this mutates
	virtual int GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr);		// get how many branches can this mutates
	int GetNumMutCombos();
	int GetMutNextEvt( int eid );
	bool IsCoalNodeDone(const set<int> &evtCurr, int &numBranchDone);
	//void SetParent( RTACNodeInfo *p ) { pParent = p; }
	//RTACNodeInfo *GetParent() { return pParent; }
	int GetNumBranches() {return listBranches.size();}
	int GetBranch( int i, set<int> &muts) { muts = listBranches[i].first; return listBranches[i].second; } 

protected:
	int cidStart;
	int numCoalsNode;
	int numMutationEvtsLocal;
	vector< pair< set<int>, int> > listBranches;
	map< int, set<int> > mapParallelMuts;
	map<int,int> mapMutUnderCoal;
	map<int,int> mapMutCoalBelowMut;			// what is the event below a mut (can be either another mut or a coal)
	set<int> setAllLocalEvents;
	set<int> setLocalEveentsNoUnderCoals;
	//RTACNodeInfo *pParent;
};

// for use of ordered sites along branches to reduce choices
class RTACNodeInfoOrderedMuts : public RTACNodeInfo
{
public:
	RTACNodeInfoOrderedMuts(int cid, int numCoals);

	virtual void GetNextEventsFor( int evtJustAdd, const set<int> &curEvts, set<int> &nextEvts, set<int> &evtToRemove );
//	virtual int GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr);		// get how many branches can this mutates
	virtual int GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr);		// get how many branches can this mutates
};

typedef struct
{
	int eidEnd;				// the last (F.I.T) event of this lineage
	int multiplicity;		// how many copies of this lineages
	//vector<int> vecMutEvets;
	void Dump() {cout << "eidEnd = " << eidEnd << ", multiplicity = " << multiplicity << endl; }
} COAL_LINEAGE;

class RootedTreeACHelper
{
public:
	static void Init(BinaryMatrix &mat, SEQUENCE &seqRoot);
	static RootedTreeACHelper & Instance();
	~RootedTreeACHelper();

	// get a new 
	int GetNumCoalsentEvents(  set<int> &setEvents  );
	int GetNumCoalsentEvents(  vector<int> &setEvents  );
	void GetNextEventCandidates( const set<int> &setEvents, set<int> &candidates );
	void GetNextEventCandidatesForEvt( int evtNew, const set<int> &curEvents, set<int> &candidates, set<int> &evtToRemove );
	bool IsEventCoalescent(int eid);
	inline bool IsEventMutation(int eid);
	int GetLocalCoalNum(int coalid);				// get coalescent id
	int GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr);		// get how many branches can this mutates
	int GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr);		// get how many branches can this mutates
	int GetTotNumCoals() {return numCoals;}
	int GetTotNumMuts() {return numMuts;}
	void GetActiveDeadEvents( const set<int> &setACActiveEventIds, set<int> &activeList, set<int> &deadList);
	double GetTheta(int index);		// get current theta
	//void SetTheta(double t) {this->theta = t;}
	int GetNumCompatTrees();
	int GetThetaNum() {return numThetaVals;}
	void SetThetaNum(int n) {numThetaVals = n; }
	double GetThetaInc() {return thetaInc;}
	void SetThetaInc( double t) {thetaInc = t;}
	double GetThetaBegin() {return thetaBegin; }
	void SetThetaBegin(double t) {thetaBegin = t;}
	int GetSubPopulationNum() {return numSubPopulations;}
	void SetSubPopulationNum(int t) {numSubPopulations = t; }
	void SetMigrationRates( const vector< vector<double> > &migRates );
	double GetMigrationRate(int popSrc, int popDest);
	double GetComboMigrationRate(int popSrc );
	double GetEffectPopRatio(int pop);
	int GetMutationId(int edgeLabel) { return edgeLabel + numCoals; }

	// added 6/13/09
	void GetCurrLineages( const vector<int> &curEvents, vector<COAL_LINEAGE> &lineages );
	bool IsCoalNodeDone( int coalNode, const set<int> &curEvents, int &numBranchDone);
	bool IsMutNodeDone(int mutNode, const set<int> &curEvents );
	int GetEnclosingCoalEvt(int evt, const vector<int> &curEvents  );
	int GetPrevCoalEvt(int coalEvt );
	void GetMutEvtsForLineage(int evtLast, vector<int> &vecMuts);

private:
	// utilities
//	void GetSingleEventCnaidates( int evt, set<int> &candidates );
	bool IsLeadCoalescent(int evid) { return listACNodesInfo.find(evid) != listACNodesInfo.end(); }
	int GetMutEvtsOneUp( int evtLast, vector<int> &vecMuts );

	RootedTreeACHelper();

	// what else?
	// list for each node, which node to be used
	static map<int, RTACNodeInfo *> listACNodesInfo;
	static map<long, int> mapNodeToCoalId;
	static map<int, RTACNodeInfo *> mapParNodeOfLeadCoal;
	static vector<RTACNodeInfo *> listACNInfoForAllEvts;	// quick reference to which node cluster this event belongs to
	static int numCoals;
	static int numMuts;
	static double theta;			// current theta to use
	static int numThetaVals;		// how many theta value to do in one shot
	static double thetaBegin;		// which value to start
	static double thetaInc;			// the grid increment value
	static int numSubPopulations;	// num of subpopulations
	static vector< vector<double> > vecMigrationRates;
};


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// AC Storage with some basic Hashing

typedef map<int, vector<TreeAC *> > AC_MAP_LIST;
class TreeACDepotIterator;


class TreeACDepot
{
public:
	TreeACDepot();
	~TreeACDepot();	// need to deallocate space

	TreeAC* AddAC( TreeAC *pAC );
	int GetNumACs();
//	TreeAC *GetACAt(int i);
	void GetTreeACIterator( TreeACDepotIterator &itor );
	void Dump();	// dump out ACs
	void PrintFirstAC();
	void SetMaxACCapacity(int maxAC) { maxACToKeep = maxAC; }
	void Prune();
	TreeAC *FindAC( TreeAC *pACCopy );

private:
	// for caching
	void SetDirty(bool f) { fDirty = f; }
	bool IsDirty() { return fDirty; }
	TreeAC* InsertAC(TreeAC *pAC, AC_MAP_LIST &mapACs);

	bool AreSameACs(TreeAC *pAC1, TreeAC *pAC2);

	AC_MAP_LIST  mapTreeACs; 
	bool fDirty;
	int numEntriesCache;		// cached copy
	int maxACToKeep;
};


class TreeACDepotIterator
{
public:
	TreeACDepotIterator( );
	void Init( AC_MAP_LIST   *pmapTreeACs );
	void First();
	void Next();
	bool IsDone();
	TreeAC *GetCurrItem();

private:
	AC_MAP_LIST *pMapTreeACs;
	AC_MAP_LIST  :: iterator itMap;
	//AC_MAP_LIST :: iterator itList;
	int indexList;
	bool fDone;
};



/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree AC explorer
// keep track of configs that we have seen

class RootedTreeACExplorer
{
public:
	RootedTreeACExplorer(BinaryMatrix &mat, SEQUENCE &seqR);
	virtual ~RootedTreeACExplorer() {}

	virtual void Explore();
	int GetNumACSeen() { return numACSeen; }
	void SetRoot( const SEQUENCE &seqR) {seqRoot = seqR;}
	virtual TreeAC *CreateAC( const vector<int> &initEvts) { return new TreeACPanmictic(initEvts); }

protected:
	virtual void UpdateExplore();
	virtual void InitExplore();
	void ExploreStep();
	bool IsFinalReached();

//private:
	// explore the next step
	//{return pCurrACDepot->GetNumACs() == 1;}

	// current active list
	TreeACDepot *pCurrACDepot;
	TreeACDepot *pNextACDepot;
	int numACSeen;
	SEQUENCE seqRoot;
	BinaryMatrix &matInput;
};




#endif //TREE_CFG_EXPLORER_H
