#ifndef TREE_CFG_EXP_SUBDIVIDED
#define TREE_CFG_EXP_SUBDIVIDED

#include "TreeCfgExplorer.h"

typedef struct
{
	vector<int> vecSrcCoalSACIds;
	vector<int> vecCoalSzs;
	vector<int> vecCoalOrig;
	vector<int> vecSrcMutSACIds;
	vector<int> vecMutSzs;
} AC_SRC_RESULT;


class TreeACSubdivided : public TreeAC
{
public:
	TreeACSubdivided(const vector<int> &initEvts);
	TreeACSubdivided( const TreeACSubdivided &rhs); 
	virtual ~TreeACSubdivided();

	// sub-pop functions
	// update sub-ACs's probalbity (each sub-AC is for a particular config of population label)
	void AddAncestralAC( TreeACSubdivided *pAC )  { ancestralACs.push_back( pAC );  }
	void CalcSACProbs();
	double GetProbAt( int t, int sacId );
	void SetProbAt(int t, int sacId, double prob);
	void InitStartingProb();
	void GetCurrEvtIds( vector<int> &evtIds ) { evtIds = setACActiveEventIds;  }

	// interfaces
	int GetNumSeqs() ;	// = num of coalescent + 1 
	bool IsSame( TreeAC *pAC ) ;
	void GetNextACs( vector<TreeAC *> &listNewACs ) ;
	void Dump() ;
	void AddActiveEvent(int evid ) ;
	void Consolidate() ;
	int GetSignature( ) ;  // useful in hashing
	double GetProb(int index) ;
	void UpdateByCoalescent( int numSeq, int numCoalSeq ) ;
	void UpdateByMutation( int numSeq, int numMutSeq  ) ;
	void Aggregate( TreeAC *pAC ) ;
	double GetEstProbRemain() ;
	int GetNumCurEvts();

private:
	// 
	void UpdateNextEvents( int eid, set<int> &setNextEvents );
	bool IsSameSubdivid( TreeACSubdivided *pAC );
	int GetNumSACs();
	//int GetSACId( const vector<COAL_LINEAGE> &lineages, const vector<int> &listPopSeqsNum );
	//bool ConvSACIdToPopNumList(  const vector<COAL_LINEAGE> &lineages, int sacId, vector<int> &listPopSeqsNum );
	void ObtainSrcSAC( TreeACSubdivided *pACSrc, const vector<COAL_LINEAGE> &lineagesDest, 
		const vector< vector<int> > &listPopSeqsNum, AC_SRC_RESULT &result);
	double CalcCoalescentMutProbPart( double theta, const vector<int> &vecPopTotSz, const vector<int> &vecPopPartSz,const vector<int> &vecPopOrig,
		const vector<double> &vecPartProb, const vector<int> &vecMutSz, const vector<double> &vecMutProb, const vector< vector<int> > &enumPartsId ) ;
	void FindMigNgbrs( const vector<vector<int> > &partEnumId, vector<double> &vecMigFactors, vector<int> &vecSACIds );
	void SolveLinearEquations( int numCols, int *Ap, int *Ai, double *Ax, double *b,  double *sol );
	void CalcMigStatesProb(	vector< vector< int> > &vecFirstSACIndex,
	vector<  vector<double> > &vecFirstSACCoeff,
	vector< vector<int> > &vecRelatedSACIndex,
	vector< vector<double> > &vecRelatedSACCoeffs,
	vector< vector<double> > &vecRHS);
	double CalcProbDenom( const vector< vector<int> > &popDivId, double theta, const vector<double> &vecMigRateOut );
	double GetInitProb(int nPopIndex);

	// data
	vector<int> setACActiveEventIds;
	double **pProbValue;

	vector<TreeACSubdivided *> ancestralACs;
};


// exploring other???

class SubdividedRTreeACExplorer : public RootedTreeACExplorer
{
public:
	SubdividedRTreeACExplorer(BinaryMatrix &mat, SEQUENCE &seqR, const vector<int> &listPLIn);
	virtual ~SubdividedRTreeACExplorer() {}

	virtual TreeAC *CreateAC(const vector<int> &initEvts) ;
	virtual void Explore();

protected:
	virtual void UpdateExplore();
	virtual void InitExplore();


private:
	void GetMutSitesFromRoot( const SEQUENCE &seq, set<int> &mutSites );

	vector<int> listPopLabels;;
};



#endif

