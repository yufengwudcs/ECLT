#include "TreeCfgExplorer.h"
#include "PhylogenyTree.h"
#include "unistd.h"
#include <algorithm>


// what else?
// list for each node, which node to be used
map<int, RTACNodeInfo *> RootedTreeACHelper :: listACNodesInfo;
map<long, int> RootedTreeACHelper :: mapNodeToCoalId;
vector<RTACNodeInfo *> RootedTreeACHelper :: listACNInfoForAllEvts;	// quick reference to which node cluster this event belongs to
int RootedTreeACHelper :: numCoals;
int RootedTreeACHelper :: numMuts;
double RootedTreeACHelper :: theta;
int RootedTreeACHelper :: numThetaVals = 1;	// how many theta value to do in one shot
double RootedTreeACHelper :: thetaBegin = 2.0;	// which value to start
double RootedTreeACHelper :: thetaInc = 0.0;		// the grid increment value
int RootedTreeACHelper :: numSubPopulations = 1;
vector< vector<double> > RootedTreeACHelper :: vecMigrationRates;
map<int, RTACNodeInfo *> RootedTreeACHelper :: mapParNodeOfLeadCoal;

///////////////////////////////////////////////////////////////////////////////////////////////////////

//const int MAX_MAP_SIZE = 50;
static int numACToKeepLimit = -1;
static int numACAbortLimit = HAP_MAX_INT;


void SetACKeepLimit(int limit)
{
	numACToKeepLimit = limit;
}

int GetACKeepLimit()
{
	return numACToKeepLimit;
}

void SetACAbortLimit(int limit)
{
	numACAbortLimit = limit;
}
int GetACAbortLimit()
{
	return numACAbortLimit;
}

void OutputGeneTreeMatrix( BinaryMatrix &mat, char *filename )
{
	// open the file
	ofstream outfile( filename );

	map<SEQUENCE, int> mapSeqFreqs;
    mat.GetSeqsFeqs( mapSeqFreqs );
	for( map<SEQUENCE, int> :: iterator it = mapSeqFreqs.begin(); it != mapSeqFreqs.end(); ++it )
	{
		outfile << it->second << " : ";
		for( int k=0; k<(int) it->first.size(); ++k )
		{
			outfile << it->first[k] << " ";
		}
		outfile << endl;
	}
}

void OutputGeneTreeMatrixStruct( BinaryMatrix &mat, const char *filename, const vector<int> &popLabels )
{
	// remember which row is from which index
	YW_ASSERT_INFO( (int)popLabels.size() == mat.GetRowNum(), "Input size wrong." );
	// 
	map<SEQUENCE, pair<int,int> > mapSeqFreqs;
	for(int i=0; i<(int)mat.GetRowNum(); ++i)
	{
		SEQUENCE seq;
		mat.GetRow(i, seq);
		YW_ASSERT_INFO( popLabels[i] == 1 || popLabels[i] == 2, "Currently only support either population1 or 2." );
		if(  mapSeqFreqs.find(seq) == mapSeqFreqs.end() )
		{
			pair<int,int> pp(0,0);
			mapSeqFreqs.insert( map<SEQUENCE, pair<int,int> > :: value_type(seq, pp) );
		}
		if(popLabels[i] == 1 )
		{
			mapSeqFreqs[seq].first ++;
		}
		else
		{
			mapSeqFreqs[seq].second ++;
		}
	}

	// open the file
	ofstream outfile( filename );

	for( map<SEQUENCE, pair<int,int> > :: iterator it = mapSeqFreqs.begin(); it != mapSeqFreqs.end(); ++it )
	{
		vector<int> popList;
		vector<int> popOrigList;
		if(it->second.first > 0 )
		{
			popList.push_back(it->second.first);
			popOrigList.push_back(0);
		}
		if(it->second.second > 0 )
		{
			popList.push_back(it->second.second);
			popOrigList.push_back(1);
		}
		for(int j=0; j<(int)popList.size(); ++j)
		{
			outfile << popOrigList[j] << "  ";
			outfile << popList[j] << " : ";
			for( int k=0; k<(int) it->first.size(); ++k )
			{
				outfile << it->first[k] << " ";
			}
			outfile << endl;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// A simple Hash function

/* UNIX ELF hash
 * Published hash algorithm used in the UNIX ELF format for object files
 */
static unsigned int hashELF(char *name, int len)
{
	unsigned int h = 0, g;

	for ( int i=0; i<len; ++i ) {
		h = ( h << 4 ) + *name++;
		if ( g = h & 0xF0000000 )
		h ^= g >> 24;
		h &= ~g;
	}

	return h;
}

/* djb2
 * This algorithm was first reported by Dan Bernstein
 * many years ago in comp.lang.c
 */
static unsigned long hashDJB2(char *str, int len)
{
	unsigned int hash = 5381;
	//int c; 
	for(int i=0; i<len; ++i) 
	{
		hash = ((hash << 5) + hash) + str[i]; // hash*33 + c
	}
	return hash;
}
static unsigned long hashDJB2(const set<char> &buf)
{
	unsigned int hash = 5381;
	//int c; 
	for(set<char> :: iterator it = buf.begin(); it != buf.end(); ++it) 
	{
		hash = ((hash << 5) + hash) + (*it); // hash*33 + c
	}
	return hash;
}
unsigned long hashDJB2(const vector<int> &buf)
{
	unsigned int hash = 5381;
	//int c; 
	for(int i=0; i<(int)buf.size(); ++i) 
	{
		char ch = buf[i];
		hash = ((hash << 5) + hash) + ch; // hash*33 + c
	}
	return hash;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree config
// if empty, it means the single ancestral sequence

TreeACPanmictic :: TreeACPanmictic(const vector<int> &initEvts) : setACActiveEventIds(initEvts)
//, hashVal( -1 )
{
	// create a temp set
//	pSetTempIds = new set<int>;
	pProbValue = new double[RootedTreeACHelper::Instance().GetThetaNum() ];
	for(int i=0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i)
	{
		pProbValue[i] = 1.0;
	}
}

TreeACPanmictic :: TreeACPanmictic( const TreeACPanmictic &rhs) : setACActiveEventIds(rhs.setACActiveEventIds)  //, 
	//setNextEvents( rhs.setNextEvents )
	//probValue(rhs.probValue)
	//, hashVal(rhs.hashVal)
{
	// create a temp set
//	pSetTempIds = new set<int>(*(rhs->pSetTempIds));
	pProbValue = new double[RootedTreeACHelper::Instance().GetThetaNum() ];
	for(int i=0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i)
	{
		pProbValue[i] = rhs.pProbValue[i];
	}
}

TreeACPanmictic :: ~TreeACPanmictic()
{
	delete [] pProbValue;
}

// more?
int TreeACPanmictic :: GetNumSeqs()
{
	// num seq = number of coalescent event + 1
	int res = 1; 
	//set<int> setInt;
	//ConvCharSetToIntSet(this->setACActiveEventIds, setInt);
	//PopulateSetByVec( setInt, this->setACActiveEventIds );
	//res += RootedTreeACHelper :: Instance().GetNumCoalsentEvents(setInt);
	res += RootedTreeACHelper :: Instance().GetNumCoalsentEvents(this->setACActiveEventIds);
		
	return res;
}

int TreeACPanmictic :: GetIdsSum()
{
	// simply get the sum of all numbers in it
	int res = 0;
	for( vector<int> :: iterator it = this->setACActiveEventIds.begin(); it != this->setACActiveEventIds.end(); ++it )
	{
		res += *it;
	}
	return res;
}

bool TreeACPanmictic :: IsSame( TreeAC *pAC ) 
{
	TreeACPanmictic *pACPan = dynamic_cast<TreeACPanmictic *>(pAC);
	if( pACPan != NULL )
	{
		return IsSamePanmictic(pACPan); 
	}
	else
	{
		// not the same if of different type
		return false;
	}
}

bool TreeACPanmictic :: IsSamePanmictic( TreeACPanmictic *pAC )
{
//	if( GetSimpleHash() != pAC->GetSimpleHash() )
//	{
//		return false;
//	}
	if( this->setACActiveEventIds.size() != pAC->setACActiveEventIds.size() )
	{
		return false;
	}
	//if( GetIdsSum() != pAC->GetIdsSum() )
	//{
	//	return false;
	//}
	for( int i=0; i<(int) this->setACActiveEventIds.size(); ++i )
	{
		if( this->setACActiveEventIds[i] != pAC->setACActiveEventIds[i] )
		{
			return false;
		}
	}
	return true;

//	set<int> ss1, ss2;
//	PopulateSetByVec(ss1, this->setACActiveEventIds);
//	PopulateSetByVec(ss2, pAC->setACActiveEventIds);
//	return ss1 == ss2;
//	return IsVecSame(this->setACActiveEventIds, pAC->setACActiveEventIds);

	
	//return this->setACActiveEventIds == pAC->setACActiveEventIds;

#if 0
	if( this->setACActiveEventIds.size() != pAC->setACActiveEventIds.size()  )
	{
		return false;
	}

	// how to test for equal? Simply search iteration of two list
	// they have to match exactly
	set<char> :: iterator it1, it2;
	for( it1 = this->setACActiveEventIds.begin(),
		it2 = pAC->setACActiveEventIds.begin();
		it1 != this->setACActiveEventIds.end() && it2 != pAC->setACActiveEventIds.end(); it1++, it2++)
	{
		if( *it1 != *it2 )
		{
			return false;
		}
	}
	return true;

//	return this->setACActiveEventIds == pAC->setACActiveEventIds;
	//&& this->setACDeadEventIds == pAC->setACDeadEventIds;
#endif
}

void TreeACPanmictic :: AddActiveEvent(int evid )
{
	// for now, add to temp only
//	this->pSetTempIds.insert(evid);

//#if 0
	// add it to active list
	//vector<int>::iterator it;
	//it = find( this->setACActiveEventIds.begin(), this->setACActiveEventIds.end(), evid );
	//if( it == this->setACActiveEventIds.end() )
	{
		InsertOrderedVec(this->setACActiveEventIds, evid);
		//this->setACActiveEventIds.push_back( evid );
		// sort it
		//SortIntVec( this->setACActiveEventIds );
	}

	// update next event list
//	UpdateNextEvents( evid );

	// update signature
//	CalcHashVal();
	//CalcSimpleHash();
//#endif
}

void TreeACPanmictic :: GetNextACs( vector<TreeAC *> &listNewACs  )
{
	listNewACs.clear();

	// get a list of new reachable ACs from here
	//set<int> evtNextCandidates;
	//RootedTreeACHelper::Instance().GetNextEventCandidates( this->setACActiveEventIds, evtNextCandidates );

	// find out what next events to explore from the current active ones
	//set<int> setCurEvts;
	//PopulateSetByVec( setCurEvts, this->setACActiveEventIds );
	set<int> setNextEvents;
	for( vector<int> :: iterator it = this->setACActiveEventIds.begin(); it != this->setACActiveEventIds.end(); ++it )
	{
		int evtCur = *it;
		UpdateNextEvents(evtCur, setNextEvents);
	}

	// make sure no dead events is listed
//	SubtractSets( evtNextCandidates, this->setACDeadEventIds);

	int numSeqs = this->GetNumSeqs();
//cout << "GetNextACs: numSeqs = "<< numSeqs << endl;
//this->Dump();

	// for now, every event is placed to active
	for( set<int> :: iterator it = setNextEvents.begin(); it != setNextEvents.end(); ++it )
	{
		//set<int> evtIdActive = this->setACActiveEventIds;
//		set<int> evtIdDead = this->setACDeadEventIds;
		// add to active ids. TBD!
		//evtIdActive.insert( *it );

		TreeACPanmictic *pAC = new TreeACPanmictic( *this );

		// add something to it
		//pAC->setACActiveEventIds = this->setACActiveEventIds;
		//pAC->setACActiveEventIds.insert( *it );
		//pAC->setNextEvents = this->setNextEvents;

		// Update next events
		//pAC->UpdateNextEvents( *it  );

		// update signature
		//pAC->CalcHashVal();

		// add one more event
		pAC->AddActiveEvent( *it );

		// update its prob here
		if( RootedTreeACHelper::Instance().IsEventCoalescent(*it) == true )
		{
			// this is a coalescent event
			int numCoalSeq = RootedTreeACHelper::Instance().GetLocalCoalNum(*it) + 1;
			// mutation event
			set<int> setEvtsInt;
			//ConvCharSetToIntSet( pAC->setACActiveEventIds, setEvtsInt );
			PopulateSetByVec( setEvtsInt, pAC->setACActiveEventIds );
			int numMutedBranches = RootedTreeACHelper::Instance().GetNumLocalMutEvtBranches(*it, setEvtsInt);
			pAC->UpdateByCoalescent( numSeqs+1, numCoalSeq - numMutedBranches);
		}
		else
		{
			// mutation event
			set<int> setEvtsInt;
//			ConvCharSetToIntSet( pAC->setACActiveEventIds, setEvtsInt );
			PopulateSetByVec( setEvtsInt, pAC->setACActiveEventIds );
			int numMutChoices = RootedTreeACHelper::Instance().GetNumLocalMutEvtChoices(*it, setEvtsInt);
//			int numMutChoices = 1;
			pAC->UpdateByMutation( numSeqs, numMutChoices  );
		}


//		pAC->CalcSimpleHash();

//		pAC->setACDeadEventIds = evtIdDead;

		// consolidate
//		pAC->Consolidate();

		listNewACs.push_back( pAC );
	}
}

void TreeACPanmictic :: Dump()
{
	cout << "AC contains: active events = ";
	DumpIntVec( this->setACActiveEventIds );
//	DumpIntSet( this->setACDeadEventIds);
//	cout<< "Next events = ";
//	DumpSet( this->setNextEvents );
	for(int i =0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i )
	{
		cout << "Prob = " << GetProb(i) << endl;
	}
}

void TreeACPanmictic :: Consolidate()
{
YW_ASSERT_INFO(false, "wrong");
	// update the active/dead list by moving no-longer-active nodes to dead list
	//set<int> activeList, deadList;
	//RootedTreeACHelper::Instance().GetActiveDeadEvents( this->setACActiveEventIds, activeList, deadList);
	// append deadlist
//	UnionSets(this->setACDeadEventIds, deadList);
	// update new active list
	//this->setACActiveEventIds = activeList;
}

void TreeACPanmictic :: UpdateNextEvents( int eid, set<int> &setNextEvents )
{
//cout << "UpdateNextEvents: eid = " << eid << endl;
	// update next event candidates after adding this new eid
	// remove the current added event
	setNextEvents.erase( eid );

	// append new events
	set<int> evtCandidates, evtToRemove;	//, setActiveEventsInt;
	
//	ConvCharSetToIntSet(this->setACActiveEventIds, setActiveEventsInt);
	set<int> setActiveEvtChars;
	//FillCharSet(setActiveEvtChars, this->setACActiveEventIds);
	PopulateSetByVec(setActiveEvtChars, this->setACActiveEventIds);
	RootedTreeACHelper::Instance().GetNextEventCandidatesForEvt( eid, setActiveEvtChars, evtCandidates, evtToRemove );
//cout << "evtCandidates = ";
	// append this to new ones (but can not have the original ones)
//	set<int> setJoin;
//	JoinSets(evtCandidates, this->setACActiveEventIds, setJoin);
//YW_ASSERT_INFO( setJoin.size() == 0, "Join sets non empty: Very wrong" );
//	SubtractSets( evtCandidates, this->setACActiveEventIds );
//	set<char> evtChars1, evtChars2;
//	ConvIntSetToCharSet( evtCandidates, evtChars1);
//	ConvIntSetToCharSet( evtToRemove, evtChars2);

	for(set<int> :: iterator it = evtCandidates.begin(); it != evtCandidates.end(); ++it)
	{
		//
		setNextEvents.insert( (int)*it );
	}
	for(set<int> :: iterator it = evtToRemove.begin(); it != evtToRemove.end(); ++it)
	{
		//
		setNextEvents.erase( (int)*it );
	}


	//UnionSets( this->setNextEvents, evtChars1 );
	//SubtractSets( this->setNextEvents, evtChars2 );

}

int TreeACPanmictic :: GetSignature( )
{
	// useful in hashing
	// for now, just use the sum
	//int res = 0;
	//for(set<int> :: iterator it = setACActiveEventIds.begin(); it != setACActiveEventIds.end(); ++it )
	//{
		//
	//	res += *it;
	//}
//	const int MAX_RANGE = 797;
//	res = (res % MAX_RANGE);
	//return res;

	//return this->hashVal;
	return hashDJB2( this->setACActiveEventIds );
}

#if 0
int TreeAC :: CalcHashVal()
{
	int hashVal = hashDJB2( this->setACActiveEventIds );
	return hashVal;
//	int res = 0;
//	char *pbuf = new char[setACActiveEventIds.size()];
//	int p = 0;
//	for(set<char> :: iterator it = setACActiveEventIds.begin(); it != setACActiveEventIds.end(); ++it )
//	{
//		//
//		res += *it;
//		pbuf[p++] = (char)(*it);
//	}
////	const int MAX_RANGE = 797;
////	res = (res % MAX_RANGE);
////	this->hashVal = res;
//	this->hashVal = hashDJB2(pbuf, setACActiveEventIds.size() );
//	delete pbuf;
}
#endif

//void TreeACPanmictic :: CalcSimpleHash()
//{
//  int  hash;
//  int len = setACActiveEventIds.size();
//  hash = len;
//  for (set<int> :: iterator it = setACActiveEventIds.begin(); it != setACActiveEventIds.end(); ++it )
//  {
//    hash = (hash >> 8) ^ (*it);
//  }
//
//  hashVal2= hash;
//}

//int TreeAC :: GetSimpleHash()
//{
//	return hashVal2;
//}


void TreeACPanmictic :: UpdateByCoalescent( int numSeq, int numCoalSeq  )
{
	// n is the number of sequence AFTER such operation
	// numCoalSeq is the num AFTER duplicate
	YW_ASSERT_INFO(numCoalSeq >= 2, "Fail");
//cout << "numSeq = " << numSeq << ", nmCoal = " << numCoalSeq << ", orig prob = " << GetProb()  << endl;
	// update the prob by a factor
	for(int i =0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i )
	{
		double theta = RootedTreeACHelper::Instance().GetTheta(i);
	//	double denom = numSeq*(numSeq-1+ theta  );
		double denom = (numSeq-1+ theta  );
	//cout << "theta = " << theta << ", denom = " << denom << endl;
	//	this->probValue *= numCoalSeq*(numCoalSeq-1)/denom;
		this->pProbValue[i] *= (numCoalSeq-1)/denom;
	}
//cout << "Coalescent update of prob to " << GetProb() << endl;
}

void TreeACPanmictic :: UpdateByMutation( int numSeq, int numMutSeq )
{
	YW_ASSERT_INFO(numSeq >= 2, "Fail2");
//cout << "numSeq = " << numSeq << ", numMutSeq = " << numMutSeq << ", orig prob = " << GetProb()  << endl;

	// update the prob by a factor
	for(int i =0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i )
	{
		double denom = numSeq*(numSeq-1+ RootedTreeACHelper::Instance().GetTheta(i)  );
		this->pProbValue[i] *= RootedTreeACHelper::Instance().GetTheta(i) * numMutSeq/denom;
//cout << "Mutation update of prob to " << GetProb() << endl;
	}
}

void TreeACPanmictic :: Aggregate( TreeAC *pAC )
{
//cout << "Prev prob = " << GetProb() << ", and pAC's prob = " << pAC->GetProb() << endl;
	// sum of prob value by this new AC (for each theta)
	for(int i=0; i<RootedTreeACHelper::Instance().GetThetaNum(); ++i)
	{
		this->pProbValue[i] += pAC->GetProb(i);
	}
//cout << "After aggregate: ";
//Dump();
}

double TreeACPanmictic :: GetEstProbRemain()
{
// non-informative
return 1.0;

#if 0
	//very rough est of coal/mut prob to the end
	int ns = GetNumSeqs();
	int numCoalsDone = ns - 1;
	int numCoal = RootedTreeACHelper::Instance().GetTotNumCoals() - numCoalsDone ;
	int numMuts;
	numMuts = RootedTreeACHelper::Instance().GetTotNumMuts()  - (GetNumCurEvts() - numCoalsDone);
//if( numCoal <0 || numMuts < 0 )
//{
//cout << "Curr evts = ";
//DumpSet(setACActiveEventIds);
//cout << "ns = " << ns << ", numCoal = " << numCoal << ", numMuts = " << numMuts << endl;
//}
	YW_ASSERT_INFO( numCoal >=0 && numMuts >= 0, "Fail1" );
	double res = 1.0;
	double theta = RootedTreeACHelper::Instance().GetTheta();
	for( int i=0; i<numCoal; ++i   )
	{
		res *= (ns + i + 1)/( theta + ns + i + 1  );
	}
	for(int i=0; i<numMuts; ++i)
	{
		res *= theta/( theta + ns + numCoal +i + 1 );
	}
//cout << "Est prob remains = " << res << endl;
	return res;
#endif
}

//void  TreeAC :: FillCharSet( set<char> &sc, const vector<int> &veci )
//{
//	sc.clear();
//	for(int i=0; i<(int)veci.size(); ++i)
//	{
//		char ch = (char) veci[i];
//		sc.insert( ch );
//	}
//}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree config helper for explore purpoose
// Assume: all-0 sequence as tree root
// Caution: care should be taken at multifuricated tree node:
// e.g. suppose the out-degree is 4 (i.e. 3 coalescent events, named as a,b,c)
// and there are x,y,z,w events (mutation or coal) for each outgoing 
// Then a is always the first, followed by b and c last
// each time, if say x follows a, then the next can NOT be y,z,w!
// instead, either we continue to explore at x down, OR we have to
// introduce b. Another way is to avoid 
// IN GENERAL: only the last (c in this case) can choose
// two. 

// recordiing at each node of perfect phylogeny
// the constraints at the root
RTACNodeInfo :: RTACNodeInfo(int cid, int numCoals) : cidStart( cid), numCoalsNode(numCoals), numMutationEvtsLocal(0)
{
	// add the list of coals to its list
	PopulateSetWithInterval(setAllLocalEvents, cid, cid + numCoals-1 );
	setLocalEveentsNoUnderCoals = setAllLocalEvents;
//cout << "Creating a node info with cid = " << cid << ", numCoals = " << numCoals;
//cout << ", setAllLocalEvents = ";
//DumpIntSet( setAllLocalEvents );
}

// use -1 to indicate leaf reached
void RTACNodeInfo :: AddBranch( const set<int> &branchEvents, int coalEnd )
{
//cout << "Attach a branch with coalEnd = " << coalEnd << ", branch mutation events = ";
//DumpIntSet( branchEvents );
	pair<set<int>,int> pp(branchEvents, coalEnd);
	listBranches.push_back( pp );

	// add a record for parrelel muts if needed
	numMutationEvtsLocal += branchEvents.size();
	if( branchEvents.size() > 0 )
	{
		for(set<int> :: iterator it = branchEvents.begin(); it != branchEvents.end(); ++it)
		{
			set<int> restMuts = branchEvents;
			restMuts.erase( *it );
			mapParallelMuts.insert( map<int,set<int> > :: value_type( *it, restMuts ) );
//cout << "Create an entry for mut = " << *it << endl;
			// for each mutation, also put an underlying coal if possible
			if( coalEnd >= 0)
			{
				mapMutUnderCoal.insert( map<int,int> :: value_type( *it, coalEnd ) );
			}
		}
	}

	//
	UnionSets( setAllLocalEvents, branchEvents );
//cout << "Update event = setAllLocalEvents" ;
//DumpIntSet( setAllLocalEvents);
	UnionSets( setLocalEveentsNoUnderCoals, branchEvents );
	if( coalEnd >= 0 )
	{
		// note, do not include for no-underlying coalescents
		setAllLocalEvents.insert( coalEnd );
	}

	// setup the mutation info
	for( set<int> :: iterator it = branchEvents.begin(); it != branchEvents.end(); ++it )
	{
		// 
		set<int> :: iterator itnext = it;
		itnext++;
		if( itnext != branchEvents.end() )
		{
			// there is one more mutation below it
			mapMutCoalBelowMut.insert( map<int,int> :: value_type(*it, *itnext) );
		}
		else
		{
			// no more mutation below it, so use the coalEnd
			mapMutCoalBelowMut.insert( map<int,int> :: value_type(*it, coalEnd) );
		}
	}
}

// get next possible events
void RTACNodeInfo :: GetNextEvents(  set<int> &curEvts, set<int> &nextEvts  )
{
//cout << "GetNextEvents: curEvts = ";
//DumpIntSet( curEvts );
	// handle each cur events
	//set<int> listMuts;
	//GetCurMutNodes( listMuts );

	// if lead coal is not in, do nothing
	if( curEvts.find(cidStart) == curEvts.end() )
	{
		return;
	}


	int numCoalInRange = 0;
	//int numMutsDone = 0;
	bool fCoalAdded = false;
	//set<int> mutsCurDone;
	for( set<int> :: reverse_iterator it = curEvts.rbegin(); it != curEvts.rend(); ++it)
	{
		int cevt = *it;
		// if it is coalescent
		if(  IsCoalEvtInRange(cevt) == true  )
		{
			if( numCoalInRange == 0 )
			{
				// in range number = cevt-begin+1
				numCoalInRange = cevt - this->cidStart + 1;
//cout << "numCoalInRange = " << numCoalInRange << endl;
			}
			if( fCoalAdded == false )
			{
				// add a next evt to it
				int coalNew = cevt+1;
				if( IsCoalEvtInRange( coalNew ) == true && curEvts.find( coalNew ) == curEvts.end() )
				{
//				YW_ASSERT_INFO( curEvts.find( coalNew) == curEvts.end(), "false here" );
					nextEvts.insert( coalNew);
					fCoalAdded = true;
//cout << "Adding new node: " << coalNew << endl;
					break;
				}
			}
		}
		// see if mutation can say something
		//if( listMuts.find( cevt ) != listMuts.end()  )
		//{
		//	mutsCurDone ++;
		//}
	}

	int numDoneBranches = 0;
	set<int> setDownCoals;
	set<int> setBranchMuts;
	for(int ii=0; ii<(int)listBranches.size(); ++ii)
	{
		// test if this branch is fully done
		set<int> setJoin;
		JoinSets(listBranches[ii].first, curEvts, setJoin);
		//bool fMutInc  = true;
		if( setJoin.size() > 0 )
		//if( listBranches[ii].first.size() == 0 || IsSetContainer( curEvts, listBranches[ii].first ) == true  )
		{
			// this branch has been touched
			numDoneBranches ++;
			// when all mutations are included, also include downstream coal if possible
			if( setJoin.size() == listBranches[ii].first.size() &&
				listBranches[ii].second >= 0 &&   curEvts.find(listBranches[ii].second) == curEvts.end()  )
			{
				nextEvts.insert( listBranches[ii].second );
			}
			else if( setJoin.size() < listBranches[ii].first.size()  )
			{
				// put the rest of mutations in
				set<int> setRest = listBranches[ii].first;
				SubtractSets( setRest, setJoin );
				UnionSets( nextEvts, setRest );
			}
			//if(listBranches[ii].first.size() > 0  && listBranches[ii].second  >= 0 )
			//{
			//	setDownCoals.insert( listBranches[ii].second );
			//}
		}
		//else if( IsSetContainer( curEvts, listBranches[ii].first ) == true )
		//{
			//
		//	numDoneBranches ++;
			//if( listBranches[ii].second >= 0 && curEvts.find(listBranches[ii].second) == curEvts.end()  )
		//}
		else
		{
			// if branch mutation set is empty, but there is a valid down coals, then
			// if this coal is in, the branch has taken
			if( listBranches[ii].first.size() == 0 && 
				listBranches[ii].second >= 0     )
			{
				if(curEvts.find(listBranches[ii].second) == curEvts.end() )
				{
					setDownCoals.insert( listBranches[ii].second );
				}
				else
				{
					numDoneBranches ++;
				}
			}

			if( listBranches[ii].first.size() > 0 )
			{
				// also consider mutations as well
				// keep track of mutations
				set<int> branchMutsLocal = listBranches[ii].first;
				SubtractSets( branchMutsLocal, curEvts );
				UnionSets(setBranchMuts, branchMutsLocal);
			}
		}

	}
//cout << "Num done branches = " << numDoneBranches << ", numCoalInRange = " << numCoalInRange << ", tot coalescent num = " 
//<< GetNumLocalCoalescents() << endl;
	// add it if there if (1) all coalescents have been done or (2) the number of branch is not over number of
	if( numCoalInRange == GetNumLocalCoalescents() ||  numDoneBranches < numCoalInRange  )
	{
//cout << "Adding branch muts = ";
//DumpIntSet( setBranchMuts );
//cout << "Adding down coalescents = ";
//DumpIntSet( setDownCoals );
		//
		UnionSets( nextEvts, setBranchMuts );
		UnionSets( nextEvts, setDownCoals );
	}
}


void RTACNodeInfo :: GetNextEventsFor( int evtJustAdd, const set<int> &curEvts, set<int> &nextEvts, set<int> &evtToRemove  )
{
//cout << "GetNextEventsFor: evtJustAdd = " << evtJustAdd << endl;
//cout << "GetNextEventsFor: curEvt = ";
//DumpSet( curEvts );
	int numCoalInRange = 0;

	// for speedup, construct an array
	//int totSize = RootedTreeACHelper::Instance().GetTotNumCoals() + 
	//	RootedTreeACHelper::Instance().GetTotNumMuts();
	//bool *listCurEvts = new bool[ totSize ];
	//for( int i=0; i<totSize; ++i )
	//{
	//	listCurEvts[i] = false;
	//}
	//for( set<char> :: iterator it = curEvts.begin(); it != curEvts.end(); ++it )
	//{
	//	listCurEvts[ (int)*it ] = true;
	//}



	// use binary search to find the largest current coal. event
	int minCoal = this->cidStart;
	int maxCoal = this->cidStart + numCoalsNode-1;
	if( maxCoal > *curEvts.rbegin() )
	{
		maxCoal = *curEvts.rbegin();
	}
	int coalLargestInRange = minCoal;
	while( minCoal <= maxCoal )
	{
		// see whether ???
		int curCoal = (minCoal + maxCoal)/2;
		//if( listCurEvts[curCoal] == true )
		if(  curEvts.find( curCoal ) != curEvts.end()  )
		{
			coalLargestInRange = curCoal;
			// move one to the left
			minCoal = curCoal + 1;
		}
		else
		{
			maxCoal = curCoal - 1;
		}
	}
	numCoalInRange =  coalLargestInRange - this->cidStart + 1;
//cout << "numCoalInRange = " << numCoalInRange << endl;

	// we should also start to work on underlying branches (if possible)
	int numDoneBranches = 0;
	vector<bool> isBranchDone( listBranches.size()  );
	for(int ii=0; ii<(int)listBranches.size(); ++ii)
	{
		isBranchDone[ ii ] = false;
		// test if this branch is fully done
		for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
		{
			if( curEvts.find( *it111 ) != curEvts.end()  )
			//if( listCurEvts[ *it111 ] == true )
			{
				isBranchDone[ii] = true;
				numDoneBranches ++;
				break;
			}
		}

		// if not, also see whether underlying coal is done
		if( isBranchDone[ii] ==  false && listBranches[ii].first.size() == 0 && 
				listBranches[ii].second >= 0     )
		{
			//if( listCurEvts[ listBranches[ii].second ] == true )
			if(curEvts.find(listBranches[ii].second) != curEvts.end() )
			{
				isBranchDone[ii] = true;
				numDoneBranches ++;
			}
		}
	}
//cout << "Number of done branches = " << numDoneBranches << endl;
//cout << "Number of branches = " << listBranches.size() << endl;

	// for each true branch, add more if we can
	for( int ii=0; ii<(int)listBranches.size(); ++ii  )
	{
		if(  isBranchDone[ii] == true )
		{
//cout << "Branch " << ii << " is touched\n";
			// try to add on-branch muts, if we can
			bool fAdded = false;
			for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
			{
				//if( listCurEvts[ *it111 ] == false )
				if( curEvts.find( *it111) == curEvts.end()  )
				{
//cout << "Adding to a already touched branch's mutation = " << *it111 << endl;
					//pair<set<int> :: iterator, bool> res = ;
					nextEvts.insert( *it111);
				//if( res.second == true )
				//{
					fAdded = true;
				}
			}
			if( fAdded == false && listBranches[ii].second >= 0 
				//&& listCurEvts[ listBranches[ii].second ] == false
				&& curEvts.find( listBranches[ii].second  ) == curEvts.end() 
				)
			{
//cout << "Addiing a already touched branch a tail coalescent = " << listBranches[ii].second << endl;
				nextEvts.insert( listBranches[ii].second );
			}
		}
		else
		{
//cout << "Branch " << ii << " is not touched\n";
			// add only if done branch does not exceed # of coal
			if( IsCoalEvtInRange( evtJustAdd ) == true  )
			{
				if( numCoalInRange == GetNumLocalCoalescents() ||  numDoneBranches < numCoalInRange  )
				{
					// add all mutants
					for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
					{
						nextEvts.insert( *it111);
					}
					if(  listBranches[ii].first.size() == 0 &&  listBranches[ii].second >= 0 )
					{
						nextEvts.insert( listBranches[ii].second );
					}
				}
			}
			else
			// if muts exceed coal?
			{
				// this is a mutation event, should exclude other mutantions in this case
				if( numCoalInRange < GetNumLocalCoalescents() &&   numDoneBranches == numCoalInRange   )
				{
					// add all mutants
					for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
					{
						evtToRemove.insert( *it111);
					}
					if(  listBranches[ii].first.size() == 0 &&  listBranches[ii].second >= 0 )
					{
						evtToRemove.insert( listBranches[ii].second );
					}
				}
			}
		}
	}

	// finally add more coal if possible
	// if it is a coalescent event, we can then add the next coal if not exceeding the range
	int evtNew = evtJustAdd + 1;
	if( IsCoalEvtInRange( evtNew ) == true )
	{
		// add it
//cout << "Add the next coalescent event: " << evtNew << endl;
		nextEvts.insert( evtNew );
	}

//cout << "nextEvts = ";
//DumpIntSet( nextEvts );
//cout << "evtToRemove = ";
//DumpIntSet( evtToRemove );


	// free
	//delete [] listCurEvts;



#if 0
	int numDoneBranches = 0;
	set<int> setDownCoals;
	set<int> setBranchMuts;
	for(int ii=0; ii<(int)listBranches.size(); ++ii)
	{
		// test if this branch is fully done
		set<int> setJoin;
		for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
		{
			if( curEvts.find( (char)(*it111) ) != curEvts.end()  )
			{
				setJoin.insert( *it111 );
			}
		}
		//JoinSets(listBranches[ii].first, curEvts, setJoin);
		//bool fMutInc  = true;
		if( setJoin.size() > 0 )
		{
			// this branch has been touched
			numDoneBranches ++;
			// when all mutations are included, also include downstream coal if possible
			if( setJoin.size() == listBranches[ii].first.size() &&
				listBranches[ii].second >= 0 &&   curEvts.find((char)listBranches[ii].second) == curEvts.end()  )
			{
				nextEvts.insert( listBranches[ii].second );
			}
			else if( setJoin.size() < listBranches[ii].first.size()  )
			{
				// put the rest of mutations in
				set<int> setRest = listBranches[ii].first;
				SubtractSets( setRest, setJoin );
				UnionSets( nextEvts, setRest );
			}
		}
		else
		{
			// if branch mutation set is empty, but there is a valid down coals, then
			// if this coal is in, the branch has taken
			if( listBranches[ii].first.size() == 0 && 
				listBranches[ii].second >= 0     )
			{
				if(curEvts.find((char)listBranches[ii].second) == curEvts.end() )
				{
					setDownCoals.insert( listBranches[ii].second );
				}
				else
				{
					numDoneBranches ++;
				}
			}

			if( listBranches[ii].first.size() > 0 )
			{
				// also consider mutations as well
				// keep track of mutations
				//set<int> branchMutsLocal = listBranches[ii].first;
				//SubtractSets( branchMutsLocal, curEvts );
				UnionSets(setBranchMuts, listBranches[ii].first);
			}
		}

	}


	// we just added an event, what can we do?
	//int numMutsDone = 0;
	// if this is a coalescent event just added
//	bool fMutsBoundReached = false;
	if( IsCoalEvtInRange( evtJustAdd ) == true  )
	{
		// if it is a coalescent event, we can then add the next coal if not exceeding the range
		int evtNew = evtJustAdd + 1;
		if( IsCoalEvtInRange( evtNew ) == true )
		{
			// add it
//cout << "Add the next coalescent event: " << evtNew << endl;
			nextEvts.insert( evtNew );

			// have one more coal in range
			//numCoalInRange ++;
		}
	

		if( numCoalInRange == GetNumLocalCoalescents() ||  numDoneBranches < numCoalInRange  )
		{
	//cout << "Adding branch muts = ";
	//DumpIntSet( setBranchMuts );
	//cout << "Adding down coalescents = ";
	//DumpIntSet( setDownCoals );
			//
			UnionSets( nextEvts, setBranchMuts );
			UnionSets( nextEvts, setDownCoals );
		}

	}
	else
	//if( IsCoalEvtInRange( evtJustAdd ) == false )
	{
//cout << "Mutation mode: numCoalInRange = " << numCoalInRange << ", tot coal num = " << GetNumLocalCoalescents();
//cout << ", num of done branch = " << numDoneBranches << endl;
		// get rid of all branch mutation/coalescent event if exceeding our limit
		if( numCoalInRange < GetNumLocalCoalescents() &&   numDoneBranches == numCoalInRange  )
		{
	//cout << "Adding branch muts = ";
	//DumpIntSet( setBranchMuts );
	//cout << "Adding down coalescents = ";
	//DumpIntSet( setDownCoals );
			//
			UnionSets( evtToRemove, setBranchMuts );
			UnionSets( evtToRemove, setDownCoals );
//cout << "Removing subset: ";
//DumpIntSet( evtToRemove );
		}

#if 0
		// this is a mutation event
		// in this case, we can add a parallel mut or a underlying coalescent event to it
		YW_ASSERT_INFO( mapParallelMuts.find(evtJustAdd )  != mapParallelMuts.end(), "Mutation map wrong"  );
		if( mapParallelMuts[evtJustAdd].size() > 0  )
		{
			// this branch is not done yet, so we should continue to add the rest of mutations
			set<int> mutToAdd;  // = mapParallelMuts[evtJustAdd];
			//SubtractSets( mutToAdd, curEvts );
			for( set<int> :: iterator it111 = mapParallelMuts[evtJustAdd].begin(); it111 != mapParallelMuts[evtJustAdd].end(); ++it111 )
			{
				if( curEvts.find( (char) *it111 ) == curEvts.end()  )
				{
					mutToAdd.insert( *it111 );
				}
			}
			UnionSets( nextEvts, mutToAdd );
			SubtractSets( evtToRemove, mutToAdd );
//			SubtractSets( evtToRemove, mapParallelMuts[evtJustAdd] );
		}
		else
		{
			// when it is done, we can only try underlying branch
			if( mapMutUnderCoal.find( evtJustAdd ) != mapMutUnderCoal.end() )
			{
				nextEvts.insert( mapMutUnderCoal[evtJustAdd] );
//				evtToRemove.erase( mapMutUnderCoal[evtJustAdd]  );
			}
		}
#endif

	}
#endif


}

void RTACNodeInfo :: GetCurCoalNodes(set<int> &nodes)
{
	nodes.clear();
	// get current nodes, embedded could be multiple if the degree >2
//	YW_ASSERT_INFO( false, "not implemented" );
	PopulateSetWithInterval( nodes, cidStart, cidStart + numCoalsNode-1);
}

void RTACNodeInfo :: GetCurMutNodes(set<int> &nodes)
{
	// get current nodes, mutations under the current node
	//YW_ASSERT_INFO( false, "not implemented" );
	nodes.clear();
//	vector< pair< set<int>, int> > listBranches;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		UnionSets( nodes, listBranches[i].first  );
	}
}

int RTACNodeInfo :: GetCurMutsBranchNum( const set<int> &nodes)
{
	// get current nodes, mutations under the current node
	//YW_ASSERT_INFO( false, "not implemented" );
	int res = 0;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		set<int> setInt;
		JoinSets(  listBranches[i].first , nodes, setInt );
		if( setInt.size() > 0 )
		{
			res ++;
		}
	}
	return res;
}

int RTACNodeInfo :: GetLocalCoalNum(int coalid)
{
	return coalid - this->cidStart + 1;
}

int RTACNodeInfo :: GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr)
{
	int numBranchNum = 0;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		set<int> setInt;
		JoinSets(  listBranches[i].first , evtCurr, setInt );
		if( setInt.size() > 0 )
		{
			numBranchNum ++;
			if( setInt.find(mutid) != setInt.end() && setInt.size() >=2)
			{
				// result is one as always, because it has other parallel muts
				return 1;
			}
		}
		else if( listBranches[i].second >= 0 && evtCurr.find( listBranches[i].second ) != evtCurr.end()   )
		{
			// in this case, the underlying coal is used, then this is also considered to be used
			numBranchNum++;
		}
	}
//cout << "branch num = " << numBranchNum << endl;
	//
	set<int> localCoalEvts;
	GetCurCoalNodes( localCoalEvts );
	set<int> curlocalCEs;
	JoinSets( localCoalEvts, evtCurr, curlocalCEs);
//cout << "curlocalCEs.size = " << curlocalCEs.size() << endl;
	int res =  curlocalCEs.size() + 1 - numBranchNum + 1;

	//if( res < 1 )
	//{
		// this means all branches have at least one mutation, and so there is no possible duplicate
	//	res = 1;
	//}
	//else
	//{
	//	res++;
	//}
	//YW_ASSERT_INFO( res >= 1, "Wrong" );
//res = 1;
	return res;
	//set<int> curCoalEvts;
	//JoinSets(localCoalEvts, evtCurr, curCoalEvts);
	// this is how many coal being derived
}

int RTACNodeInfo :: GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr)
{
	int numBranchNum = 0;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		set<int> setInt;
		JoinSets(  listBranches[i].first , evtCurr, setInt );
		if( setInt.size() > 0 )
		{
			numBranchNum ++;
		}
	}

	return numBranchNum;
}

int RTACNodeInfo :: GetNumMutCombos()
{
	int res = 1;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		if( listBranches[i].first.size() > 0 )
		{
			for(int k=1; k<=(int)listBranches[i].first.size(); ++k)
			{
				res *= k;
			}
		}
	}
	return res;
}

int RTACNodeInfo :: GetMutNextEvt( int eid )
{
	YW_ASSERT_INFO(mapMutCoalBelowMut.find( eid) != mapMutCoalBelowMut.end(), "RTACNodeInfo: mut id is not in");
	return mapMutCoalBelowMut[eid];
}

bool RTACNodeInfo :: IsCoalNodeDone(const set<int> &curEvts, int &numBranchDone)
{
	// is this coal node done???
	bool fDone = true;
	//vector<bool> isBranchDone( listBranches.size()  );
	// retrn number of done branches
	numBranchDone = 0;
	for(int ii=0; ii<(int)listBranches.size(); ++ii)
	{
		bool fDoneBranch = false;
		// test if this branch is fully done
		for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
		{
			if( curEvts.find( *it111 ) != curEvts.end()  )
			//if( listCurEvts[ *it111 ] == true )
			{
				fDoneBranch = true;
				numBranchDone ++;
				break;
			}
		}

		// if not, also see whether underlying coal is done
		if( fDoneBranch ==  false && listBranches[ii].first.size() == 0 && 
				listBranches[ii].second >= 0     )
		{
			//if( listCurEvts[ listBranches[ii].second ] == true )
			if(curEvts.find(listBranches[ii].second) != curEvts.end() )
			{
				fDoneBranch = true;
				numBranchDone ++;
			}
		}

		if( fDoneBranch == false)
		{
			fDone = false;
		}
	}
	return fDone;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// for use of ordered sites along branches to reduce choices

RTACNodeInfoOrderedMuts :: RTACNodeInfoOrderedMuts(int cid, int numCoals) : RTACNodeInfo(cid, numCoals)
{
}

void RTACNodeInfoOrderedMuts :: GetNextEventsFor( int evtJustAdd, const set<int> &curEvts, set<int> &nextEvts, set<int> &evtToRemove )
{
	// here we should only add muts in the increasing order (along the branch)
	int numCoalInRange = 0;

	// for speedup, construct an array
	int totSize = RootedTreeACHelper::Instance().GetTotNumCoals() + 
		RootedTreeACHelper::Instance().GetTotNumMuts();
	bool *listCurEvts = new bool[ totSize ];
	for( int i=0; i<totSize; ++i )
	{
		listCurEvts[i] = false;
	}
	for( set<int> :: iterator it = curEvts.begin(); it != curEvts.end(); ++it )
	{
		listCurEvts[ (int)*it ] = true;
	}



	// use binary search to find the largest current coal. event
	int minCoal = this->cidStart;
	int maxCoal = this->cidStart + numCoalsNode-1;
	if( maxCoal > *curEvts.rbegin() )
	{
		maxCoal = *curEvts.rbegin();
	}
	int coalLargestInRange = minCoal;
	while( minCoal <= maxCoal )
	{
		// see whether ???
		int curCoal = (minCoal + maxCoal)/2;
		if( listCurEvts[curCoal] == true )
	//	if(  curEvts.find( curCoal ) != curEvts.end()  )
		{
			coalLargestInRange = curCoal;
			// move one to the left
			minCoal = curCoal + 1;
		}
		else
		{
			maxCoal = curCoal - 1;
		}
	}
	numCoalInRange =  coalLargestInRange - this->cidStart + 1;
//cout << "numCoalInRange = " << numCoalInRange << endl;

	// we should also start to work on underlying branches (if possible)
	int numDoneBranches = 0;
	vector<bool> isBranchDone( listBranches.size()  );
	for(int ii=0; ii<(int)listBranches.size(); ++ii)
	{
		isBranchDone[ ii ] = false;
		// test if this branch is fully done
		for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
		{
			//if( curEvts.find( (char)(*it111) ) != curEvts.end()  )
			if( listCurEvts[ *it111 ] == true )
			{
				isBranchDone[ii] = true;
				numDoneBranches ++;
			}
			break;
		}

		// if not, also see whether underlying coal is done
		if( isBranchDone[ii] ==  false && listBranches[ii].first.size() == 0 && 
				listBranches[ii].second >= 0     )
		{
			if( listCurEvts[ listBranches[ii].second ] == true )
			//if(curEvts.find((char)listBranches[ii].second) != curEvts.end() )
			{
				isBranchDone[ii] = true;
				numDoneBranches ++;
			}
		}
	}
//cout << "Number of done branches = " << numDoneBranches << endl;
//cout << "Number of branches = " << listBranches.size() << endl;

	// for each true branch, add more if we can
	for( int ii=0; ii<(int)listBranches.size(); ++ii  )
	{
		if(  isBranchDone[ii] == true )
		{
//cout << "Branch " << ii << " is touched\n";
			// try to add on-branch muts, if we can
			bool fAdded = false;
			for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
			{
				if( listCurEvts[ *it111 ] == false )
				//if( curEvts.find((char) *it111) == curEvts.end()  )
				{
//cout << "Adding to a already touched branch's mutation = " << *it111 << endl;
					//pair<set<int> :: iterator, bool> res = ;
					nextEvts.insert( *it111);
				//if( res.second == true )
				//{
					fAdded = true;

					// now done
					break;
				}
			}
			if( fAdded == false && listBranches[ii].second >= 0 
				&& listCurEvts[ listBranches[ii].second ] == false
				//&& curEvts.find( listBranches[ii].second  ) == curEvts.end() 
				)
			{
//cout << "Addiing a already touched branch a tail coalescent = " << listBranches[ii].second << endl;
				nextEvts.insert( listBranches[ii].second );
			}
		}
		else
		{
//cout << "Branch " << ii << " is not touched\n";
			// add only if done branch does not exceed # of coal
			if( IsCoalEvtInRange( evtJustAdd ) == true  )
			{
				if( numCoalInRange == GetNumLocalCoalescents() ||  numDoneBranches < numCoalInRange  )
				{
					// add all mutants
					for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
					{
						nextEvts.insert( *it111);
						break;
					}
					if(  listBranches[ii].first.size() == 0 &&  listBranches[ii].second >= 0 )
					{
						nextEvts.insert( listBranches[ii].second );
					}
				}
			}
			else
			// if muts exceed coal?
			{
				// this is a mutation event, should exclude other mutantions in this case
				if( numCoalInRange < GetNumLocalCoalescents() &&   numDoneBranches == numCoalInRange   )
				{
					// add all mutants
					for( set<int> :: iterator it111 = listBranches[ii].first.begin(); it111 != listBranches[ii].first.end(); ++it111)
					{
						evtToRemove.insert( *it111);
						break;
					}
					if(  listBranches[ii].first.size() == 0 &&  listBranches[ii].second >= 0 )
					{
						evtToRemove.insert( listBranches[ii].second );
					}
				}
			}
		}
	}

	// finally add more coal if possible
	// if it is a coalescent event, we can then add the next coal if not exceeding the range
	int evtNew = evtJustAdd + 1;
	if( IsCoalEvtInRange( evtNew ) == true )
	{
		// add it
//cout << "Add the next coalescent event: " << evtNew << endl;
		nextEvts.insert( evtNew );
	}

//cout << "nextEvts = ";
//DumpIntSet( nextEvts );
//cout << "evtToRemove = ";
//DumpIntSet( evtToRemove );


	// free
	delete [] listCurEvts;


}
#if 0
int RTACNodeInfoOrderedMuts :: GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr)
{
	int numBranchNum = 0;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		//set<int> setInt;
		//JoinSets(  listBranches[i].first , evtCurr, setInt );
		if(   listBranches[i].first.size() > 0 && evtCurr.find( *listBranches[i].first.begin() ) != evtCurr.end()   )
		{
			numBranchNum ++;
//			if( setInt.find(mutid) != setInt.end() && setInt.size() >=2)
			set<int> :: iterator it = listBranches[i].first.begin();
			if(   listBranches[i].first.size() > 1   )
			{
				it++;
				if(evtCurr.find( *it ) != evtCurr.end())
				{
					// result is one as always, because it has other parallel muts
					return 1;
				}
			}
		}
		else if( listBranches[i].second >= 0 && evtCurr.find( listBranches[i].second ) != evtCurr.end()   )
		{
			// in this case, the underlying coal is used, then this is also considered to be used
			numBranchNum++;
		}
	}
//cout << "branch num = " << numBranchNum << endl;
	//
	set<int> localCoalEvts;
	GetCurCoalNodes( localCoalEvts );
	set<int> curlocalCEs;
	JoinSets( localCoalEvts, evtCurr, curlocalCEs);
//cout << "curlocalCEs.size = " << curlocalCEs.size() << endl;
	int res =  curlocalCEs.size() + 1 - numBranchNum + 1;

	//if( res < 1 )
	//{
		// this means all branches have at least one mutation, and so there is no possible duplicate
	//	res = 1;
	//}
	//else
	//{
	//	res++;
	//}
	//YW_ASSERT_INFO( res >= 1, "Wrong" );
//res = 1;
	return res;
	//set<int> curCoalEvts;
	//JoinSets(localCoalEvts, evtCurr, curCoalEvts);
	// this is how many coal being derived
}
#endif

int RTACNodeInfoOrderedMuts :: GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr)
{
	int numBranchNum = 0;
	for(int i=0; i<(int) listBranches.size(); ++i)
	{
		set<int> setInt;
		//JoinSets(  listBranches[i].first , evtCurr, setInt );
		if(   listBranches[i].first.size() > 0 && evtCurr.find( *listBranches[i].first.begin() ) != evtCurr.end()   )
		{
			numBranchNum ++;
		}
		else if( listBranches[i].first.size() == 0 &&  listBranches[i].second >= 0 &&  
			evtCurr.find(listBranches[i].second ) != evtCurr.end() )
		{
			numBranchNum++;
		}
	}

	return numBranchNum;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////

void RootedTreeACHelper :: Init(BinaryMatrix &mat, SEQUENCE &seqRoot)
{
	// 
	numCoals = mat.GetRowNum()-1;
	numMuts = mat.GetColNum();
	// theta init to 1.0
	//theta = 1.0;


	// 
	listACNInfoForAllEvts.clear();
	listACNInfoForAllEvts.resize( numCoals + numMuts );
	for(int i=0; i<(int)listACNInfoForAllEvts.size(); ++i)
	{
		listACNInfoForAllEvts[i] = NULL;
	}

	// build a perfect phylogeny for the mat
	PhylogenyTree tree; 

	// set root if we need
	if( seqRoot.size() != 0 )
	{
		tree.SetRoot( seqRoot );
	}

	bool f = tree.ConsOnBinMatrix( mat );
	if( f == false )
	{
		cout << "The data violates the infinite sites model.\n";
		YW_ASSERT_INFO(false, "Stop");
	}
tree.OutputGML("tmptree.gml");
//string strTree;
//tree.ConsNewick( strTree );
//cout << "Newick tree = " << strTree << endl;
	// now start tree walk to collect info
	int curCoalIdDec = RootedTreeACHelper:: Instance().GetTotNumCoals()-1;
	vector<TreeNode *> listTreeNodes;
	tree.InitPostorderWalk();
	while(true)
	{
		TreeNode *pn = tree.NextPostorderWalk();
		if( pn == NULL )
		{
			break;
		}
		int numChildren = pn->GetChildrenNum();
		// YW: temp fix. TBD 061709
		YW_ASSERT_INFO(  numChildren != 1, "Can not have degenerate nodes" );
		if( numChildren >= 1 )
		{
			int numCoalsThisNode = numChildren - 1;
			listTreeNodes.push_back( pn );
			// remember this node
			YW_ASSERT_INFO( curCoalIdDec >= 0, "Underneath node id wrong" );
			int nodeHeadId = curCoalIdDec-numCoalsThisNode+1;
			mapNodeToCoalId.insert( map<long,int> :: value_type( (long)pn,  nodeHeadId) );
//cout << "Find a major coalescent node id = " << nodeHeadId << endl;
			curCoalIdDec -= numCoalsThisNode;
		}
	}

	int coalIdCur = 0;
	for(int iii= (int)listTreeNodes.size()-1; iii>=0;  --iii)
	{
		TreeNode *pn = listTreeNodes[iii];
		// assign nodes id
		int numChildren = pn->GetChildrenNum();
		if( numChildren == 0 )
		{
			// LEAF, do nothing
			continue;
		}
		int numCoalsThisNode = numChildren - 1;
		// 04/1/08 change: add mutation in order
		RTACNodeInfo *pNodeInfo = new RTACNodeInfoOrderedMuts( coalIdCur, numCoalsThisNode );
		// how about mutations?????
		for(int i=0; i<pn->GetChildrenNum(); ++i)
		{
			vector<int> listEdgeLabels;
			pn->GetEdgeLabelsAtBranch(i, listEdgeLabels);
//cout << "For branch i= " << i <<  ", edge labels = ";
//DumpIntVec( listEdgeLabels );

			// convert to event id
			for(int iii=0; iii<(int)listEdgeLabels.size(); ++iii)
			{
				listEdgeLabels[iii] += RootedTreeACHelper:: Instance().GetTotNumCoals();

				// for each mutation event, rememver its node cluster
				listACNInfoForAllEvts[ listEdgeLabels[iii] ] = pNodeInfo;
			}

			set<int> setLabels;
			PopulateSetByVec( setLabels, listEdgeLabels );
			// what is the node?
			int coalIdTip = -1;
			TreeNode *pnChild = pn->GetChild( i );
			YW_ASSERT_INFO( pnChild != NULL, "Child empty" );
			if( mapNodeToCoalId.find( (long)pnChild  ) != mapNodeToCoalId.end()  )
			{
				coalIdTip = mapNodeToCoalId[ (long) pnChild ];
			}
			pNodeInfo->AddBranch( setLabels, coalIdTip );

			// now remember the parent information
			if( coalIdTip >= 0)
			{
				mapParNodeOfLeadCoal.insert( map<int, RTACNodeInfo *> :: value_type(coalIdTip, pNodeInfo) );
			}
		}

		// add it
		listACNodesInfo.insert(  map<int, RTACNodeInfo *> :: value_type( coalIdCur, pNodeInfo )  );

		// rememver fo reach event which node cluster to refer to
		for(int iiii = coalIdCur; iiii<coalIdCur+numCoalsThisNode; ++iiii)
		{
			listACNInfoForAllEvts[iiii] = pNodeInfo;
		}

		// remember this node
//		mapNodeToCoalId.insert( map<int,int> :: value_type( (int)pn, coalIdCur ) );
		// 
		coalIdCur += numCoalsThisNode;
	}
}
RootedTreeACHelper& RootedTreeACHelper :: Instance()
{
	static RootedTreeACHelper inst;
	return inst;
}

RootedTreeACHelper :: ~RootedTreeACHelper()
{
	// clear out
	for( map<int, RTACNodeInfo *> :: iterator it = listACNodesInfo.begin(); it != listACNodesInfo.end(); ++it )
	{
		delete it->second;
	}
}


// get a new 
int RootedTreeACHelper :: GetNumCoalsentEvents(  set<int> &setEvents  )
{
	// 
	int res = 0;
	for(set<int> :: iterator it = setEvents.begin(); it != setEvents.end(); ++it)
	{
		if( IsEventCoalescent( *it ) == true )
		{
			res ++;
		}
	}
	return res;		// for now
}
int RootedTreeACHelper :: GetNumCoalsentEvents(  vector<int> &setEvents  )
{
	// 
	int res = 0;
	for(vector<int> :: iterator it = setEvents.begin(); it != setEvents.end(); ++it)
	{
		if( IsEventCoalescent( *it ) == true )
		{
			res ++;
		}
	}
	return res;		// for now
}
void RootedTreeACHelper :: GetNextEventCandidates( const set<int> &setEvents, set<int> &candidates )
{
	candidates.clear();
	set<int> setEventsUsed = setEvents;
	// we resort to individual tree structures to extract next move
	for( map<int, RTACNodeInfo *> :: iterator it = listACNodesInfo.begin(); it != listACNodesInfo.end(); ++it )
	{
		it->second->GetNextEvents( setEventsUsed, candidates );
	}

	//for(set<int> :: iterator it = setEvents.begin(); it != setEvents.end(); ++it)
	//{
	//	GetSingleEventCnaidates( *it, candidates );
	//}
}

void RootedTreeACHelper :: GetNextEventCandidatesForEvt( int evtNew, const set<int> &curEvents, set<int> &candidates, 
														set<int> &evtToRemove )
{
	// when a new evt is added, what new event becomes feasible?
	// find which main cluster this evt belongs to
	//candidates.clear();
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[evtNew];
	//YW_ASSERT_INFO( pNodeInfo != NULL, "node info not found" );
	pNodeInfo->GetNextEventsFor(evtNew, curEvents, candidates, evtToRemove);
}

int RootedTreeACHelper :: GetLocalCoalNum(int coalid)
{	
	// get coalescent id
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[coalid];
	return pNodeInfo->GetLocalCoalNum(coalid);
}

int RootedTreeACHelper :: GetNumLocalMutEvtChoices(int mutid, const set<int> &evtCurr)
{
	// get how many branches can this mutates
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[mutid];
	return pNodeInfo->GetNumLocalMutEvtChoices(mutid, evtCurr);
}

int RootedTreeACHelper :: GetNumLocalMutEvtBranches(int coalid, const set<int> &evtCurr)
{
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[coalid];
	return pNodeInfo->GetNumLocalMutEvtBranches(coalid, evtCurr);
}

// utilities
//void RootedTreeACHelper :: GetSingleEventCnaidates( int evt, set<int> &candidates )
//{
//	// ?????
//}
bool RootedTreeACHelper :: IsEventCoalescent(int eid)
{
	// coalescent listed first
	return eid < numCoals ;
}
bool RootedTreeACHelper :: IsEventMutation(int eid)
{
	return eid >= numCoals;
}


RootedTreeACHelper :: RootedTreeACHelper()
{
	// do nothing?
}

void RootedTreeACHelper :: GetActiveDeadEvents( const set<int> &setACActiveEventIds, 
											   set<int> &activeList, set<int> &deadList)
{
	// classify the events to active/dead
	activeList = setACActiveEventIds;
//return;
	for(set<int> :: iterator it = setACActiveEventIds.begin(); it != setACActiveEventIds.end(); ++it)
	{
		int id = *it;
		if( IsLeadCoalescent( id ) == true )
		{
			// now see whether we should move it away from active list
			// A node is dead if all its events has finished (include) all its immediate
			// mutations, coals, and underlying coal. 
			set<int> localEvtList, localEvtNoUnderCoals;
			listACNodesInfo[id]->GetAllLocalEvents( localEvtList, localEvtNoUnderCoals );

			// is this set contained in activeList
			if( IsSetContainer( activeList, localEvtList ) == true )
			{
				// get rid of the dead nodes from active list and put into dead list
				UnionSets( deadList, localEvtNoUnderCoals );
				SubtractSets( activeList, localEvtNoUnderCoals );
			}
		}
	}
}

double RootedTreeACHelper :: GetTheta(int i) 
{
	return this->thetaBegin + i*this->thetaInc;
}

int RootedTreeACHelper :: GetNumCompatTrees()
{
	// get the number of compatible trees
	int res = 1;
	for( map<int, RTACNodeInfo *> :: iterator it = listACNodesInfo.begin(); it != listACNodesInfo.end(); ++it )
	{
		res *= it->second->GetNumMutCombos();
	}
	return res;
}

void RootedTreeACHelper :: SetMigrationRates( const vector< vector<double> > &migRates )  
{ 
	vecMigrationRates = migRates; 
	YW_ASSERT_INFO( vecMigrationRates.size() > 0 && vecMigrationRates.size() == vecMigrationRates[0].size(),
		"Wrong migration paraemter\n");
}

double RootedTreeACHelper :: GetMigrationRate(int popSrc, int popDest)
{
	YW_ASSERT_INFO( popSrc < (int) vecMigrationRates.size()
		&& popDest < (int)vecMigrationRates.size(), "Population number wrong"  );
	return vecMigrationRates[popSrc][popDest];
}

double RootedTreeACHelper :: GetComboMigrationRate(int popSrc )
{
	double res = 0.0;
	for(int i=0; i<(int)vecMigrationRates.size(); ++i)
	{
		if( i != popSrc )
		{
			res += vecMigrationRates[popSrc][i];
		}
	}
	return res;
}

double RootedTreeACHelper :: GetEffectPopRatio(int pop) 
{
	// assume for now, the population size is same
	YW_ASSERT_INFO(numSubPopulations > 0, "Population not set");
	return 1.0/numSubPopulations;
}

void RootedTreeACHelper :: GetCurrLineages( const vector<int> &curEventsVec, vector<COAL_LINEAGE> &lineages )
{
	set<int> curEvents;
	PopulateSetByVec(curEvents, curEventsVec);

	set<int> setEidsDone;
//cout << "GetCurrLineages: curEventsVec: ";
//DumpIntVec( curEventsVec );
	// obtain set of lineages of this AC (with the events set)
	// first find events that are terminal (i.e. not all its descendents are done)
	for( set<int> :: iterator it = curEvents.begin(); it != curEvents.end(); ++it)
	{
//cout << "GetCurrLineages: cur evt = " << *it << endl;
		RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[*it];
		YW_ASSERT_INFO(pNodeInfo != NULL, "Can not be NULL");
		//set<int> evtSet, evtNoUnderCoal;
		//pNodeInfo->GetAllLocalEvents( evtSet, evtNoUnderCoal );
//cout << "evtSet: ";
//DumpIntSet( evtSet );
		// is this node done
		//if( IsSetContainer(curEvents, evtSet) == false )
		//{
			// if this is mutation event, add it (and lineage number is 1)
			if( IsEventMutation( *it ) == true )
			{
				// only do when mutation node is not done
				if( IsMutNodeDone( *it, curEvents ) == false )
				{
//cout << "Adding a mutation lineage: eidEnd = " << *it << endl;
					COAL_LINEAGE lin;
					lin.eidEnd = *it;
					lin.multiplicity = 1;
					lineages.push_back( lin  );
				}
			}
			else 
			{
				int numBranchDone = 0;
				if( IsCoalNodeDone(*it, curEvents, numBranchDone) == true )
				{
					continue;
				}
				// determine whether this is the last coalescent event done
				int ceidLast = -1;
				for(int ceid = 0; ceid < pNodeInfo->GetNumLocalCoalescents(); ++ceid)
				{
					// is this coal evet here?
					int cidStep = ceid + pNodeInfo->GetLeadCoalescentId();
					if( curEvents.find(cidStep) != curEvents.end() )
					{
						ceidLast = cidStep;
					}
					else
					{
						break;
					}
				}
				YW_ASSERT_INFO( ceidLast >= 0, "ceidLast can not be negative" );
				if( setEidsDone.find( ceidLast ) != setEidsDone.end() )
				{
					// old one, skip
					continue;
				}
				setEidsDone.insert( ceidLast );
				COAL_LINEAGE lin;
				lin.eidEnd = ceidLast;
				//set<int> mutEvetsLocal;
				//JoinSets(evtSet, curEvents,  mutEvetsLocal);
				//SubtractSets( mutEvetsLocal, evtNoUnderCoal);
				//lin.multiplicity = ceidLast - pNodeInfo->GetLeadCoalescentId() - mutEvetsLocal.size()  + 1;
				lin.multiplicity = ceidLast - pNodeInfo->GetLeadCoalescentId() - numBranchDone  + 2;
				YW_ASSERT_INFO( lin.multiplicity > 0, "lin.multiplicity : can not be zero" );
				lineages.push_back( lin  );
//cout << "cidLast = " << ceidLast << ", cidfirst = " << pNodeInfo->GetLeadCoalescentId() ;
//cout << "lin.multiplicity = " << lin.multiplicity << endl;
//cout << "Mutaiton evts done: ";
//DumpIntSet(mutEvetsLocal);
			}
		//}
	}

	YW_ASSERT_INFO( lineages.size() > 0, "lineages: can not be NULL" );
//cout << "In GetCurrLineages: number of constructed lineages: " << lineages.size() << endl;
	// figure out number
}


bool RootedTreeACHelper :: IsCoalNodeDone( int coalNode, const set<int> &curEvents, int &numBranchDone )
{
	// is this coalescent event done (meaning no more offspring possible)
	YW_ASSERT_INFO( IsEventCoalescent(coalNode) == true, "IsCoalNodeDone: Not a coalescent node" );
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[coalNode];

	return pNodeInfo->IsCoalNodeDone(curEvents, numBranchDone);
}

bool RootedTreeACHelper :: IsMutNodeDone(int mutNode, const set<int> &curEvents )
{
	// mean the mutation is terminal (its offspring, if any) has already been generated
	// if the mutation has no offspring possible, return false (not done)
	// firsg get the node
	YW_ASSERT_INFO( IsEventMutation(mutNode) == true, "IsMutNodeDone: Not a mutation node" );
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[mutNode];
	int mcNext = pNodeInfo->GetMutNextEvt(mutNode);
	if( mcNext < 0 )
	{
		return false;
	}
	return curEvents.find( mcNext) != curEvents.end();
}

int RootedTreeACHelper :: GetEnclosingCoalEvt(int mutEvt, const vector<int> &curEventsVec  )
{
	set<int> curEvents;
	PopulateSetByVec( curEvents,  curEventsVec);
	// get the coalescent event that is enclosing the current evt
	YW_ASSERT_INFO( IsEventMutation( mutEvt ) == true, "GetEnclosingCoalEvt: not a mutation node"  );
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[mutEvt];
	// which coal event is in curevts
	for(int t= pNodeInfo->GetLeadCoalescentId() + pNodeInfo->GetNumLocalCoalescents()-1; t>= pNodeInfo->GetLeadCoalescentId(); --t)
	{
		if( curEvents.find( t ) != curEvents.end() )
		{
			return t;
		}
	}

	return -1;
}

int RootedTreeACHelper :: GetPrevCoalEvt(int coalEvt )
{
	YW_ASSERT_INFO( IsEventCoalescent( coalEvt ) == true, "GetEnclosingCoalEvt: not a mutation node"  );
	RTACNodeInfo *pNodeInfo = listACNInfoForAllEvts[coalEvt];
	if( pNodeInfo->GetLeadCoalescentId() != coalEvt )
	{
		// then just one less
		return coalEvt-1;
	}
	else
	{
		// fail to find
		return -1;
	}
}

void RootedTreeACHelper :: GetMutEvtsForLineage(int evtLast, vector<int> &vecMuts)
{
	// find the list of mutations for entire lineage all the way to root
	vecMuts.clear();

	//
	int evtCur = evtLast;
	while(evtCur >= 0 )
	{
		evtCur = GetMutEvtsOneUp( evtCur, vecMuts );
	}
}

int RootedTreeACHelper :: GetMutEvtsOneUp( int evtLast, vector<int> &vecMuts )
{
	// return the event id of the upwards lineage when nothing more to get backwards
	YW_ASSERT_INFO(evtLast >= 0, "evtLast: invalid");
	// from current event, reach its immediate ancestor and pick up mutations on this branch
	// NOTE: WE WILL COLLECT ALL MUTATIONS ON THIS BRANCH (EVEN FOR MUTATIONS UNDER IT)
	RTACNodeInfo *pNodeInfo;
	
	int eidres = -1;
	int evtLastTip = evtLast;
	if( IsEventCoalescent(evtLast) == false )
	{
		pNodeInfo = listACNInfoForAllEvts[evtLast];
	}
	else
	{
		// find the
		RTACNodeInfo *pn1 = listACNInfoForAllEvts[ evtLast ] ;
		int clead = pn1->GetLeadCoalescentId();
//cout << "clead = " << clead << endl;
		if( mapParNodeOfLeadCoal.find( clead ) == mapParNodeOfLeadCoal.end()  )
		{
			// already at root
			return -1;
		}
		else
		{
			pNodeInfo = mapParNodeOfLeadCoal[clead];
			evtLastTip = clead;
		}
	}

	for(int i=0; i<pNodeInfo->GetNumBranches(); ++i)
	{
		set<int> evtsCurr;
		int tipEvt = pNodeInfo->GetBranch(i, evtsCurr);
		if( tipEvt == evtLastTip  || evtsCurr.find(evtLast) != evtsCurr.end() )
		{
			vector<int> vecApp;
			//save it
			PopulateVecBySet(vecApp, evtsCurr);
			AppendIntVec( vecMuts, vecApp );
			break;
		}
	}
	return pNodeInfo->GetLeadCoalescentId();
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// AC Storage with some basic Hashing

TreeACDepot :: TreeACDepot() : fDirty(false), numEntriesCache(-1), maxACToKeep(-1)
{
}

TreeACDepot :: ~TreeACDepot()
{
//	for( map<int, AC_MAP_LIST > :: iterator it =  mapTreeACs.begin(); it!= mapTreeACs.end(); ++it )
	{
		for( AC_MAP_LIST :: iterator it11 = mapTreeACs.begin(); it11 != mapTreeACs.end(); ++it11  )
		{
			for(int i=0; i<(int)it11->second.size(); ++i)
			{
				delete it11->second[i];
			}
		}
		mapTreeACs.clear();
	}
}

TreeAC* TreeACDepot :: AddAC( TreeAC *pAC )
{
#if 0
	// size
//	int numSeq = pAC->GetNumSeqs();

	// is this new?
	TreeAC *pres = NULL;
	//bool fres = true;
	int sigAC = pAC->GetSignature();
//	if( mapTreeACs.find( numSeq ) != mapTreeACs.end() )
	{
		if( mapTreeACs.find( sigAC ) != mapTreeACs.end()   )
		{
			for(int i=0; i<(int)mapTreeACs[sigAC].size(); ++i)
			{
				// 
				if( AreSameACs( pAC, mapTreeACs[sigAC][i] ) == true )
				{
					// do something more processing???

					// stop
					pres = mapTreeACs[sigAC][i];
					//fres = false;
//cout << "Dup found\n";
//cout << "pAC = ";
//pAC->Dump();
//cout << "Dup ac = ";
//pres->Dump();
					break;
				}
			}
		}
	}
//	else
//	{
//		//AC_MAP_LIST emptylist;
//		//mapTreeACs.insert(  map<int, AC_MAP_LIST > :: value_type( numSeq, emptylist ) );
//		vector<TreeAC*> listAC;
//		mapTreeACs.insert( AC_MAP_LIST :: value_type(sigAC, listAC)  );
//	}

	// if not found, just add it
	if( pres == NULL )
	//if( fres == true )
	{
		// mark the change
		SetDirty(true);

		mapTreeACs[sigAC].push_back( pAC );
	}
#endif
	TreeAC *pres = InsertAC( pAC, mapTreeACs );
	if( pres != NULL)
	{
		SetDirty(true );
	}
	return pres;
}

int TreeACDepot :: GetNumACs()
{
	if( IsDirty() == false && numEntriesCache >= 0 )
	{
		return numEntriesCache;
	}

	int res = 0;
//	for( map<int, AC_MAP_LIST > :: iterator it =  mapTreeACs.begin(); it!= mapTreeACs.end(); ++it )
	{
		for( AC_MAP_LIST :: iterator it11 = mapTreeACs.begin(); it11 != mapTreeACs.end(); ++it11  )
		{
			res += it11->second.size();
		}
	}
	// remember it in cache
	SetDirty(false);
	numEntriesCache = res;
	return res;

}

void TreeACDepot :: Dump()
{
	cout << "Number of entries in depot: " << GetNumACs() << endl;
return;

	// for now only display the first item in the prob list
	cout << "**********************************************************************\n";
//	cout << "Entry table tot size = " << mapTreeACs.size() << endl;
	//int maxTblSize = 0;
	double maxProb = 0.0;
	double minProb = 1.0;
	//for( map<int, AC_MAP_LIST > :: iterator it =  mapTreeACs.begin(); it!= mapTreeACs.end(); ++it )
	{
	//	if( (int)it->second.size() > maxTblSize )
	//	{
	//		maxTblSize = it->second.size();
	//	}
		for( AC_MAP_LIST :: iterator it11 = mapTreeACs.begin(); it11 != mapTreeACs.end(); ++it11  )
		{
			for(int i=0; i<(int) it11->second.size(); ++i)
			{
				it11->second[i]->Dump();

				if( it11->second[i]->GetProb(0) > maxProb )
				{
					maxProb = it11->second[i]->GetProb(0);
				}
				if( it11->second[i]->GetProb(0) < minProb )
				{
					minProb = it11->second[i]->GetProb(0);
				}
			}
		}
	}
	cout << "minProb = " << minProb << ", maxProb = " << maxProb << endl;
	//cout << "Largest list size in table = " << maxTblSize << endl;
}

bool TreeACDepot :: AreSameACs(TreeAC *pAC1, TreeAC *pAC2)
{
	// 
	return pAC1->IsSame( pAC2 );
}

#if 0
TreeAC *TreeACDepot :: GetACAt(int i)
{
	//if( i >= GetNumACs() )
	//{
	//	return NULL;	// out of bound
	//}
	int numsofar = 0;
	for( map<int, AC_MAP_LIST > :: iterator it =  mapTreeACs.begin(); it!= mapTreeACs.end(); ++it )
	{
		for( AC_MAP_LIST :: iterator it11 = it->second.begin(); it11 != it->second.end(); ++it11  )
		{
			// is it here
			if( i < numsofar + (int)it11->second.size() )
			{
				return it11->second[i-numsofar];
			}

			numsofar += it11->second.size();
		}
	}
	// should not be here
	return NULL;
}
#endif

void TreeACDepot :: GetTreeACIterator( TreeACDepotIterator &itor )
{
	// iterator
	itor.Init( &mapTreeACs );
	itor.First();
}

void TreeACDepot :: PrintFirstAC()
{
	//
	YW_ASSERT_INFO( GetNumACs() >= 1, "False" );
	cout << "Prob of the result = \n";
	double tmax = -1.0;
	double maxLikeli = 0.0;
	for( int i=0; i<RootedTreeACHelper :: Instance().GetThetaNum() ; ++i )
	{
		double t = RootedTreeACHelper :: Instance().GetThetaBegin() + i*RootedTreeACHelper :: Instance().GetThetaInc();
		double prob = mapTreeACs.begin()->second[0]->GetProb(i);
		cout << "Theta = " << t << ": likelihood = "  << prob << endl;

		if( prob > maxLikeli )
		{
			maxLikeli = prob;
			tmax = t;
		}
	}

	// when there is more than 1 values being computed, output the MLE
	if( RootedTreeACHelper :: Instance().GetThetaNum() > 1 )
	{
		cout << "MLE at theta = " << tmax << " with likelihood = " << maxLikeli << endl;
	}

	//cout << "For one of the compatible tree, the prob of this particular tree = ";
	//cout << mapTreeACs.begin()->second[0]->GetProb()/RootedTreeACHelper :: Instance().GetNumCompatTrees() << endl;
}

const double RATIO_TO_KEEP = 0.01;

void TreeACDepot :: Prune()
{

	// get prob and find a position for cut off
	if( maxACToKeep <= 0 ||   GetNumACs() <=  maxACToKeep )
	{
		// do nothing
		return;
	}
	// can not prune if more than one theta is being computed
	if( RootedTreeACHelper :: Instance().GetThetaNum() > 1 )
	{
		cout << "Can not prune when there is more than one theta being computed.\n";
		return;
	}

	// get the prob of all ACs
	vector<double> listProbs;
	//vector<double> listEstRemProbs;
	double maxProb = 0.0, minProb = 1.0;;
	for( AC_MAP_LIST :: iterator it11 = mapTreeACs.begin(); it11 != mapTreeACs.end(); ++it11  )
	{
		for(int i=0; i<(int) it11->second.size(); ++i)
		{
			double p = it11->second[i]->GetProb(0);
			listProbs.push_back( p );
			if( p > maxProb )
			{
				maxProb = p;
			}
			if( p < minProb )
			{
				minProb = p;
			}

				//* it11->second[i]->GetEstProbRemain());
			//listestRemProbs.push_back(   );
		}
	}

	// sort it
	//SortDoubleVec(listProbs);
	//YW_ASSERT_INFO( (int) listProbs.size() > maxACToKeep, "Wrong1" );
	//double cutoffVal = listProbs[ listProbs.size() - 1  - maxACToKeep  ];
//cout << "Current size = " << listProbs.size() << ", cutoff val = " << cutoffVal << endl;
	AC_MAP_LIST listSaveItems;
	//int posList = 0;
	for( AC_MAP_LIST :: iterator it11 = mapTreeACs.begin(); it11 != mapTreeACs.end(); ++it11  )
	{
		vector<TreeAC *> listNew;
		for(int i=0; i<(int) it11->second.size(); ++i)
		{
			double prob = it11->second[i]->GetProb(0);
			//double prob = listProbs[posList++];
			//if( it11->second[i]->GetProb() >= cutoffVal  )
			if( prob >= minProb + (maxProb-minProb) * RATIO_TO_KEEP )
			{
			//	listNew.push_back( it11->second[i]  );
				TreeAC *pres = InsertAC( it11->second[i], listSaveItems  );
				YW_ASSERT_INFO( pres == NULL, "wrong2" );
			}
			else
			{
				delete it11->second[i];
			}
		}
		// 
		//if( listNew.size() == 0 )
		//{
		//	// free up this map position
		//	mapTreeACs.erase( *it11 );
		//}
		//else
		//{
		//	it11->second = listNew;
		//}
	}

	// revert back 
	mapTreeACs = listSaveItems;


	// mark dirty
	SetDirty(true);

cout << "After prune, size = " << GetNumACs() << endl;
}

TreeAC *TreeACDepot :: InsertAC(TreeAC *pAC, AC_MAP_LIST &mapACs)
{
	// 
	// is this new?
	TreeAC *pres = NULL;
	//bool fres = true;
	int sigAC = pAC->GetSignature();
//cout << "sigAC = " << sigAC << endl;
	if( mapACs.find( sigAC ) != mapACs.end()   )
	{
		for(int i=0; i<(int)mapACs[sigAC].size(); ++i)
		{
			// 
			if( AreSameACs( pAC, mapACs[sigAC][i] ) == true )
			{
				// do something more processing???

				// stop
				pres = mapACs[sigAC][i];
				//fres = false;
//cout << "Dup found\n";
//cout << "pAC = ";
//pAC->Dump();
//cout << "Dup ac = ";
//pres->Dump();
				break;
			}
		}
	}
	else
	{
		// add a record for it
		vector<TreeAC *> listvec;
		mapACs.insert(AC_MAP_LIST:: value_type(sigAC, listvec) );
	}

	// if not found, just add it
	if( pres == NULL )
	//if( fres == true )
	{
YW_ASSERT_INFO( mapACs.find(sigAC) != mapACs.end(), "InsertAC: Not in map." );
		mapACs[sigAC].push_back( pAC );
	}
//cout << "Done: InsertAC\n";
	return pres;
}

TreeAC * TreeACDepot :: FindAC( TreeAC *pACCopy )
{
	YW_ASSERT_INFO(pACCopy != NULL, "Can not be NULL");
	int sigAC = pACCopy->GetSignature();
	if( mapTreeACs.find( sigAC ) != mapTreeACs.end()   )
	{
		for(int i=0; i<(int)mapTreeACs[sigAC].size(); ++i)
		{
			// 
			if( AreSameACs( pACCopy, mapTreeACs[sigAC][i] ) == true )
			{
				// do something more processing???

				// stop
				return  mapTreeACs[sigAC][i];
				//fres = false;
//cout << "Dup found\n";
//cout << "pAC = ";
//pAC->Dump();
//cout << "Dup ac = ";
//pres->Dump();
			}
		}
	}
	else
	{
		return NULL;
	}
	return NULL;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////

TreeACDepotIterator :: TreeACDepotIterator( )
{
}

void TreeACDepotIterator :: Init( AC_MAP_LIST  *pmt )
{
	pMapTreeACs = pmt;
}

void TreeACDepotIterator :: First()
{
	itMap = pMapTreeACs->begin();
	//itList = itMap->second.begin();
	indexList = 0;
	fDone = false;
}

void TreeACDepotIterator :: Next()
{
	// if we can move forward by indexing
	if( indexList < (int)itMap->second.size() -1  )
	{
		indexList ++;
	}
	else
	{
		indexList = 0;
		itMap ++;
		//if( itList == itMap->second.end()  )
		{
		//	itMap ++;
			if( itMap == pMapTreeACs->end() )
			{
				fDone = true;
			}
			else
			{
				//itList = itMap->second.begin();
			}
		}
	}
}

bool TreeACDepotIterator :: IsDone()
{
	return fDone;
}

TreeAC *TreeACDepotIterator :: GetCurrItem()
{
	return itMap->second[ indexList ];
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tree AC explorer
// keep track of configs that we have seen. Init values to some default: theta to be 1.0 for example

RootedTreeACExplorer :: RootedTreeACExplorer(BinaryMatrix &mat, SEQUENCE &seqR) : pCurrACDepot(NULL), pNextACDepot(NULL), numACSeen(0), matInput(mat)
{
	SetRoot( seqR );
	RootedTreeACHelper::Instance().Init(mat, seqR);
}

void RootedTreeACExplorer :: Explore()
{
	// start with an empty config
	InitExplore();
cout << "Initial AC config = ";
pCurrACDepot->Dump();

	int round = 1;
	while( true )
	{
cout << "At round " << round++ << ": ";
		//
		ExploreStep();

		// update if there are new findings
		if( IsFinalReached() == false )
		{
			UpdateExplore();
		}
		else
		{
			break;
		}
	}
	cout << "Num of ACs = " << GetNumACSeen() << endl;
//this->pCurrACDepot->Dump();

	// final result
	pCurrACDepot->PrintFirstAC();
}



// explore the next step
void RootedTreeACExplorer :: InitExplore()
{
	// put empty to
	if(pCurrACDepot != NULL)
	{
		delete pCurrACDepot;
	}
	if(pNextACDepot != NULL)
	{
		delete pNextACDepot;
	}
	pNextACDepot = NULL;
	// 
	pCurrACDepot = new TreeACDepot();
	// empty AC indicates the root
	vector<int> initEvts;
	initEvts.push_back( 0 );
	TreeAC *pAC = CreateAC(initEvts);
	// always start with event 0
	//pAC->AddActiveEvent( 0 );
	pCurrACDepot->AddAC( pAC );
	// also create the next deopt (empty for now)
	pNextACDepot = new TreeACDepot();

	// The first event is always a coalescent and thus this sets prob as well
	// and that would lead to 2 sequence and 2 coalescent afterwords
	pAC->UpdateByCoalescent(2,2);

	// we have an empty set, and also the one with a single coalescent 0
	numACSeen = 2;
}


void RootedTreeACExplorer :: ExploreStep()
{
	// For each one in current list, update the current server
	// for each current AC, build a new AC
	//int numCurACs = pCurrACDepot->GetNumACs();
	TreeACDepotIterator itor;
	pCurrACDepot->GetTreeACIterator( itor );
	itor.First();
	//for(int i=0; i<numCurACs; ++i)
	while( itor.IsDone() == false )
	{
		TreeAC *pAC = itor.GetCurrItem();
		itor.Next();
		//TreeAC *pAC = pCurrACDepot->GetACAt(i);
		// generate a new AC
		vector<TreeAC *> listNewACs;
		pAC->GetNextACs( listNewACs );
		// now append it
		for(int j=0; j<(int)listNewACs.size(); ++j)
		{
//cout << "Adding AC with address: " << (int)listNewACs[j] << endl;
			//
			TreeAC *pDupAC = pNextACDepot->AddAC( listNewACs[j] );
			if( pDupAC != NULL )
			//if( pNextACDepot->AddAC( listNewACs[j] ) == false )
			{
//cout <<"This AC is not new: now call to aggrate: pDupAC: address " << (int) pDupAC << endl;
				// sum this AC to this current AC
				pDupAC->Aggregate( listNewACs[j]  );

				// duplicate one
				delete listNewACs[j];
			}
		}
	}
//cout << "Found new ACs are: " << pNextACDepot->GetNumACs() << endl;
pNextACDepot->Dump();

}

void RootedTreeACExplorer :: UpdateExplore()
{
	// update to the next step and move forward
	// 
	delete pCurrACDepot;
	pCurrACDepot = pNextACDepot;
	YW_ASSERT_INFO( pCurrACDepot != NULL, "Can not be empty" );

	// ensure the number is not too large
	if(pCurrACDepot->GetNumACs()  >= GetACAbortLimit() )
	{
		YW_ASSERT_INFO( false, "ABORT: the number of ACs exceeds the upper limit. Stop." );
	}

	// prune the AC before proceeding
	pCurrACDepot->SetMaxACCapacity( GetACKeepLimit() );
	pCurrACDepot->Prune();


	numACSeen += pCurrACDepot->GetNumACs();
	// fresh start for next 
	pNextACDepot = new TreeACDepot;
// for now sleep a while
//sleep(1);

}

bool RootedTreeACExplorer :: IsFinalReached()
{
	return pNextACDepot->GetNumACs() == 0;
}



