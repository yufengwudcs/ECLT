#ifndef SNP_UTILS_H
#define SNP_UTILS_H

#include "Utils.h"
#include "Utils2.h"
#include "BinaryMatrix.h"
#include "UnWeightedGraph.h"


////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// some useful methods

bool ReadSNPNameFile(  const string &filename, vector<string> &nameSNPs, vector<double> &snpPos );



////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// important data structure

class SNPDistInfo
{
public:
    SNPDistInfo( );
    ~SNPDistInfo();

    // Now read in from a file
    bool ReadFromFile( const char* fileName );
    void SetRange( int range ) { totalRange = range; }
    int GetRange() {return  (int)totalRange;}
    int GetSNPNum();
    int GetSNPLoc( int i );
    double GetLocBetweenSNPs(int i, int j);
    void InitDefaultDistance(int numSNPs);
    void RemoveSNPs( const set<int> &rmSites );
	double GetSNPLocDouble(int i);
	double GetRangeDouble() {return totalRange;}

private:


	// from now on, use double as distance
    vector<double> phyLocSNPs;
    double totalRange;

};


///////////////////////////////////////////////////////////////////////////////////////////////////////////////
extern SNPDistInfo SNPDefaultDistInfo;




#endif  // ASSOCIATION_TEST_H

